#Requires AutoHotkey v2.0
#SingleInstance Force

; ── DPI awareness ────────────────────────────────────────────────────────────
; Force this process to be FULLY DPI-aware so every coordinate we use — window moves,
; ImageSearch and clicks — is in real PHYSICAL pixels, never rubber-stamped by the
; monitor's display-scaling setting (100% / 125% / 150% …).
;
; THIS is what makes the macro work on any monitor: a 1080p screen at 100% and a 1440p
; screen at 150% both end up driving Roblox at the same 1152x756 physical pixels, so the
; detection images match on both. Without it, a scaled monitor makes Windows blur/stretch
; everything and image detection fails completely.
;
; Try the strongest API first (Per-Monitor-V2, Win10 1703+), then fall back for older OS.
; MUST run before any screen-size reads or GUI creation.
dpiSet := false
try dpiSet := DllCall("user32\SetProcessDpiAwarenessContext", "Ptr", -4, "Int")  ; Per-Monitor-V2
if !dpiSet {
    try {
        DllCall("Shcore\SetProcessDpiAwareness", "UInt", 2)   ; Per-Monitor (Win8.1+)
        dpiSet := true
    }
}
if !dpiSet
    try DllCall("user32\SetProcessDPIAware")                  ; System-DPI (Vista+)

CoordMode("Pixel", "Screen")
CoordMode("Mouse", "Screen")
SetTitleMatchMode(2)
OnExit(CleanUp)

; ==============================================================================
; GLOBALS
; ==============================================================================

global SCRIPT_DIR     := A_ScriptDir
global NAV_DIR        := SCRIPT_DIR "\assets\nav\"
global REWARD_DIR     := SCRIPT_DIR "\assets\rewards\"
global GAME_TITLE     := "Roblox"
global LOOP_INTERVAL  := 50     ; ms between each state machine tick
global CLICK_DELAY    := 50     ; ms to wait after clicking a button
global IMG_VARIATION  := 40     ; strict tolerance to prevent false positives
global MAX_STATE_RETRIES := 20  ; max ticks in one state before fallback
global DEBUG_LOG      := true   ; set to false to disable debug logging

; ── Fixed Roblox window size ────────────────────────────────────────────────
; ALL nav images were captured with Roblox at exactly this pixel size.
; Changing these values WILL break image detection — never change them.
; Friends on any PC will have Roblox forced to this size automatically.
global FIXED_WIN_W := 1152
global FIXED_WIN_H := 756

; ── Physical screen dimensions (DPI-unaware, raw pixels) ─────────────────────
; We read these AFTER setting DPI awareness so we get true physical pixels.
global SCREEN_W := DllCall("GetSystemMetrics", "Int", 0, "Int")  ; SM_CXSCREEN
global SCREEN_H := DllCall("GetSystemMetrics", "Int", 1, "Int")  ; SM_CYSCREEN

; --- Roblox window bounds (set by PositionRobloxWindow, updated each Tick) ---
global WIN_X := 0
global WIN_Y := 0
global WIN_W := FIXED_WIN_W
global WIN_H := FIXED_WIN_H

; --- State Machine ---
global MacroRunning         := false
global State                := "IDLE"
global OriginalFarmMode     := ""      ; User's selection: "Challenge" | "Raid" | "Squadron"
global ActiveFarmMode       := ""      ; Currently executing mode (may temporarily be "Challenge")
global IsCheckingChallenges := false   ; true when detouring to check challenge rewards
global CheckChallenge       := false   ; GUI toggle: check challenges every 30 min
global LastRefreshInterval  := -1      ; 30-minute interval index
global WebhookURL           := ""
global WebhookEnabled      := true
global RunCount             := 0
global VictoryCount         := 0
global DefeatCount          := 0
global LeaveAttempts        := 0      ; retry counter for Leave-button clicks in DETECT_SCREEN
global RefreshLeaveTries    := 0      ; retry counter for the 30-min refresh Leave (BATTLE_END)
global StateRetries         := 0      ; generic retry counter for any state
global LastShopX            := 0      ; last known shop_icon X (for Play button offset)
global LastShopY            := 0      ; last known shop_icon Y (for Play button offset)
global ClickCount           := 0      ; global click counter to rotate 1-pixel jitter
global StartButtonSeen      := false  ; state tracking for start button detection
global RobloxHwnd           := 0      ; cached Roblox window handle

; --- Raid Config (set from GUI on Start) ---
global RaidActFile    := ""
global RaidDiffFile   := ""

; --- Squadron Config (set from GUI on Start) ---
global SquadStoryFile := ""
global SquadChapFile  := ""
global SquadDiffFile  := ""

; --- Aizen Config (set from GUI on Start) ---
global AizenDiffFile  := ""

; --- Battle timing (set when entering FARMING; used for stuck failsafe) ---
global BattleStartTick := 0

; --- Desired Rewards (populated from rewards folder) ---
global DesiredRewards     := []    ; array of filenames the user ticked ON
global RewardCheckboxes   := []    ; array of {ctrl, file} objects
global NoRewardsText      := ""    ; text control shown when no reward PNGs found

; --- Detect screen scan counter (global so StopMacro can reset it) ---
global DetectScanCount := 0

; ==============================================================================
; GUI — Build
; ==============================================================================

settingsFile := A_ScriptDir "\settings.ini"
savedWebhook := ""
webhookEnabledSaved := ""
try {
    savedWebhook := IniRead(settingsFile, "Settings", "WebhookURL")
    webhookEnabledSaved := IniRead(settingsFile, "Settings", "WebhookEnabled")
} catch {
    savedWebhook := ""
    webhookEnabledSaved := ""
}
if (webhookEnabledSaved == "" || webhookEnabledSaved == "1")
    WebhookEnabled := true
else
    WebhookEnabled := false

try TraySetIcon(A_ScriptDir "\logo.ico")
; -DPIScale: keep all GUI coordinates in raw pixels. Without this, AutoHotkey multiplies
; every control coordinate by the monitor's scaling factor (e.g. x1.5 on a 1440p screen at
; 150%), which would blow up the layout and push the embedded Roblox window out of place.
G := Gui("+AlwaysOnTop -MaximizeBox -DPIScale", "Anime Squadron AIO")

; --- Title Bar Dark Mode & Color (Windows 11) ---
; DWMWA_USE_IMMERSIVE_DARK_MODE = 20
DllCall("dwmapi\DwmSetWindowAttribute", "Ptr", G.Hwnd, "Int", 20, "Int*", 1, "Int", 4)
; DWMWA_CAPTION_COLOR = 35 (0x00bbggrr format, so 0x0C0C0C is #0C0C0C)
DllCall("dwmapi\DwmSetWindowAttribute", "Ptr", G.Hwnd, "Int", 35, "Int*", 0x2D2520, "Int", 4)

G.SetFont("s9", "Segoe UI")
G.OnEvent("Close", (*) => ExitMacro())
G.BackColor := "20252D"
G.Add("Text", "x1152 y0 w400 h800 Background1A1E24 Disabled", "")
G.SetFont("cWhite")

; ── Title ────────────────────────────────────────────────────────────────────
G.SetFont("s16 Bold cCFA356")
if FileExist(A_ScriptDir "\logo.png") {
    G.Add("Picture", "x1180 y15 w30 h30", A_ScriptDir "\logo.png")
    G.Add("Text", "x1215 y18 w265", "Anime Squadron AIO")
} else {
    G.Add("Text", "x1160 y15 w320 Center", "Anime Squadron AIO")
}
G.SetFont("s9 Norm cWhite")

; ── Start / Stop ─────────────────────────────────────────────────────────────
G.SetFont("s10 Bold c111111")
global BtnStart := G.Add("Button", "x1160 y55 w155 h40 Background345F8A", "▶ Start  (F1)")
BtnStart.OnEvent("Click", (*) => ToggleMacro())
G.SetFont("s10 Bold cWhite")
global BtnStop := G.Add("Button", "x1325 y55 w155 h40 Disabled Background444444", "⏹ Stop  (F2)")
BtnStop.OnEvent("Click", (*) => StopMacro())
G.SetFont("s9 Norm cWhite")

; ── Mode Selection (Col 1) ───────────────────────────────────────────────────
G.SetFont("cCFA356")
G.Add("GroupBox", "x1160 y105 w320 h50 cCFA356", "Farming Mode")
G.SetFont("cWhite")
global DdlMode := G.Add("DropDownList", "x1170 y125 w300 Choose1 Background1A1E24 cWhite", ["Challenge Farming", "Raid Farming", "Squadron Farming", "Aizen Farming"])
DdlMode.OnEvent("Change", (*) => RefreshModeUI())

; ── Raid Settings (Col 1) ────────────────────────────────────────────────────
global RaidControls := []
G.SetFont("cCFA356")
global GrpRaid    := G.Add("GroupBox", "x1160 y165 w320 h85 cCFA356", "Raid Settings")
G.SetFont("cWhite")
global LblRaidAct := G.Add("Text", "x1170 y185 w60 h20", "Act:")
global DdlRaidAct := G.Add("DropDownList", "x1240 y182 w230 Choose1 Background1A1E24 cWhite", ["Hidden Danger", "Saiyan Hunt", "Ruler Dragon", "The Ultimate Evil"])
global LblRaidDiff := G.Add("Text", "x1170 y217 w60 h20", "Difficulty:")
global DdlRaidDiff := G.Add("DropDownList", "x1240 y214 w230 Choose1 Background1A1E24 cWhite", ["Normal", "Hard"])
RaidControls := [GrpRaid, LblRaidAct, DdlRaidAct, LblRaidDiff, DdlRaidDiff]

; ── Squadron Settings (Col 1) ────────────────────────────────────────────────
global SquadControls := []
G.SetFont("cCFA356")
global GrpSquad      := G.Add("GroupBox", "x1160 y165 w320 h115 cCFA356", "Squadron Settings")
G.SetFont("cWhite")
global LblSquadStory := G.Add("Text", "x1170 y185 w60 h20", "Story:")
global DdlSquadStory := G.Add("DropDownList", "x1240 y182 w230 Choose1 Background1A1E24 cWhite", ["GT City", "Marine Lobby", "Ninja Village"])
DdlSquadStory.OnEvent("Change", (*) => OnSquadStoryChange())
global LblSquadChap := G.Add("Text", "x1170 y217 w60 h20", "Chapter:")
global DdlSquadChap := G.Add("DropDownList", "x1240 y214 w230 Choose1 Background1A1E24 cWhite", ["Chapter 1", "Chapter 2", "Chapter 3"])
global LblSquadDiff := G.Add("Text", "x1170 y249 w60 h20", "Difficulty:")
global DdlSquadDiff := G.Add("DropDownList", "x1240 y246 w230 Choose1 Background1A1E24 cWhite", ["Normal", "Hard"])
SquadControls := [GrpSquad, LblSquadStory, DdlSquadStory, LblSquadChap, DdlSquadChap, LblSquadDiff, DdlSquadDiff]

; ── Aizen Settings (Col 1) ───────────────────────────────────────────────────
global AizenControls := []
G.SetFont("cCFA356")
global GrpAizen     := G.Add("GroupBox", "x1160 y165 w320 h60 cCFA356", "Aizen Settings")
G.SetFont("cWhite")
global LblAizenDiff := G.Add("Text", "x1170 y185 w60 h20", "Difficulty:")
global DdlAizenDiff := G.Add("DropDownList", "x1240 y182 w230 Choose1 Background1A1E24 cWhite", ["Normal", "Hard"])
AizenControls := [GrpAizen, LblAizenDiff, DdlAizenDiff]

; ── Challenge Toggle (Col 2) ─────────────────────────────────────────────────
G.SetFont("cCFA356")
global GrpChal      := G.Add("GroupBox", "x1160 y290 w320 h50 cCFA356", "Challenge Toggle")
G.SetFont("cWhite")
global ChkChallenges := G.Add("Checkbox", "x1170 y310 w300", "Check challenges every 30 minutes")

; ── Desired Rewards (Col 2) ──────────────────────────────────────────────────
G.SetFont("cCFA356")
global GrpRewards := G.Add("GroupBox", "x1160 y350 w320 h10 cCFA356", "Desired Challenge Rewards")
G.SetFont("cWhite")
    ; LoadRewardCheckboxes() moved to bottom

; ── Discord Webhook (Col 2) ──────────────────────────────────────────────────
G.SetFont("cCFA356")
global GrpWebhook := G.Add("GroupBox", "x1160 y500 w320 h60 cCFA356", "Discord Webhook")
G.SetFont("cWhite")
global EdtWebhook := G.Add("Edit", "x1170 y525 w300 h22 Background1A1E24 cWhite", savedWebhook)
EdtWebhook.OnEvent("Change", SaveWebhookSettings)

; Enable/Disable webhook
G.SetFont("s9 Norm cWhite")
global ChkWebhookEnabled := G.Add("Checkbox", "x1170 y550 w220", "Enable webhooks")
ChkWebhookEnabled.Value := WebhookEnabled ? 1 : 0
ChkWebhookEnabled.OnEvent("Click", (*) => SaveWebhookEnabledSettings())
G.SetFont("s9 Norm cWhite")

; ── Status (Bottom) ──────────────────────────────────────────────────────────
G.SetFont("cCFA356")
global GrpStatus := G.Add("GroupBox", "x1160 y650 w320 h95 cCFA356", "Status")
G.SetFont("s10 c4A8BCA")
global TxtState  := G.Add("Text", "x1170 y675 w300 h25", "State: IDLE")
G.SetFont("s9 cCCCCCC")
global TxtStats  := G.Add("Text", "x1170 y705 w300 h35", "Runs: 0  |  Victories: 0  |  Defeats: 0")
G.SetFont("cWhite")

global GUI_WIDTH := 1490
global GUI_HEIGHT := 756

; ── Init & Show ──────────────────────────────────────────────────────────
LoadRewardCheckboxes()
RefreshModeUI()
G.Show("w" GUI_WIDTH " h" GUI_HEIGHT)
PositionRobloxWindow()   ; position Roblox at top-left on startup

ExitMacro() {
    ExitApp()
}

CleanUp(ExitReason, ExitCode) {
    global RobloxHwnd
    if (RobloxHwnd && DllCall("IsWindow", "Ptr", RobloxHwnd)) {
        DllCall("SetParent", "Ptr", RobloxHwnd, "Ptr", 0)
        winId := "ahk_id " RobloxHwnd
        WinSetStyle("+0x00C00000", winId)
        WinSetStyle("+0x00800000", winId)
        WinSetStyle("+0x00040000", winId)
        DllCall("user32\SetWindowPos", "Ptr", RobloxHwnd, "Ptr", 0, "Int", 0, "Int", 0, "Int", 0, "Int", 0, "UInt", 0x0027) ; SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED
    }
    return 0
}

IsGameActive() {
    global RobloxHwnd, GAME_TITLE, G
    if (RobloxHwnd && DllCall("IsWindow", "Ptr", RobloxHwnd)) {
        return WinActive("ahk_id " G.Hwnd) || WinActive("ahk_id " RobloxHwnd)
    }
    return WinActive(GAME_TITLE)
}

ActivateGame() {
    global RobloxHwnd, GAME_TITLE, G
    if (RobloxHwnd && DllCall("IsWindow", "Ptr", RobloxHwnd)) {
        try WinActivate("ahk_id " G.Hwnd)
    } else {
        try WinActivate(GAME_TITLE)
    }
}

; ==============================================================================
; HOTKEYS
; ==============================================================================

F1::ToggleMacro()
F2::StopMacro()
F3::CaptureDebugScreenshot()
F4::CaptureNavAsset()
F6::PositionRobloxWindow()

; ==============================================================================
; GUI HELPERS
; ==============================================================================

LoadRewardCheckboxes() {
    global RewardCheckboxes, GrpRewards, NoRewardsText, G
    RewardCheckboxes := []
    yOff := 375   ; Fixed Y for Col 2
    if DirExist(REWARD_DIR) {
        Loop Files, REWARD_DIR "*.png" {
            label := StrReplace(SubStr(A_LoopFileName, 1, -4), "_", " ")
            label := StrTitle(label)
            chk := G.Add("Checkbox", "x1170 y" yOff " w300", label)
            chk.Value := 1   ; default ON
            RewardCheckboxes.Push({ctrl: chk, file: A_LoopFileName})
            yOff += 22
        }
    }
    if (RewardCheckboxes.Length == 0) {
        NoRewardsText := G.Add("Text", "x1170 y" yOff " w300 cAAAAAA", "(No PNGs found in assets\rewards\)")
        yOff += 22
    }
    grpH := yOff - 350 + 10
    GrpRewards.Move(,,, grpH)
    
    webhookY := 350 + grpH + 15
    global GrpWebhook, EdtWebhook
    GrpWebhook.Move(, webhookY)
    EdtWebhook.Move(, webhookY + 25)
}

SaveWebhookSettings(*) {
    global EdtWebhook, WebhookEnabled
    try {
        IniWrite(Trim(EdtWebhook.Value), A_ScriptDir "\settings.ini", "Settings", "WebhookURL")
        IniWrite(WebhookEnabled ? "1" : "0", A_ScriptDir "\settings.ini", "Settings", "WebhookEnabled")
    }
}

SaveWebhookEnabledSettings(*) {
    global ChkWebhookEnabled, WebhookEnabled
    WebhookEnabled := (ChkWebhookEnabled.Value = 1)
    try {
        IniWrite(WebhookEnabled ? "1" : "0", A_ScriptDir "\settings.ini", "Settings", "WebhookEnabled")
    }
}

OnSquadStoryChange() {
    global DdlSquadStory, DdlSquadChap
    DdlSquadChap.Delete()
    if (DdlSquadStory.Text == "Ninja Village")
        DdlSquadChap.Add(["Chapter 1", "Chapter 2", "Chapter 3", "Chapter 4"])
    else
        DdlSquadChap.Add(["Chapter 1", "Chapter 2", "Chapter 3"])
    DdlSquadChap.Choose(1)
}

RefreshModeUI() {
    global DdlMode, RaidControls, SquadControls, AizenControls
    global GrpChal, ChkChallenges

    mode := DdlMode.Text
    showRaid  := (mode == "Raid Farming")
    showSquad := (mode == "Squadron Farming")
    showAizen := (mode == "Aizen Farming")
    showChal  := (mode != "Challenge Farming")

    for ctrl in RaidControls
        ctrl.Visible := showRaid
    for ctrl in SquadControls
        ctrl.Visible := showSquad
    for ctrl in AizenControls
        ctrl.Visible := showAizen

    GrpChal.Visible := showChal
    ChkChallenges.Visible := showChal
    if !showChal
        ChkChallenges.Value := 0
    else
        ChkChallenges.Enabled := true
}

UpdateStatus(stateText, extra := "") {
    global TxtState, TxtStats, State, RunCount, VictoryCount, DefeatCount
    State := stateText
    display := "State: " stateText
    if (extra != "")
        display .= " — " extra
    TxtState.Value := display
    TxtStats.Value := "Runs: " RunCount "  |  Victories: " VictoryCount
        . "  |  Defeats: " DefeatCount
}

; ==============================================================================
; START / STOP
; ==============================================================================

ToggleMacro() {
    global MacroRunning
    if MacroRunning
        StopMacro()
    else
        StartMacro()
}

StartMacro() {
    global MacroRunning, State, OriginalFarmMode, ActiveFarmMode
    global CheckChallenge, IsCheckingChallenges, LastRefreshInterval, WebhookURL
    global RaidActFile, RaidDiffFile, SquadStoryFile, SquadChapFile, SquadDiffFile, AizenDiffFile
    global DesiredRewards, RewardCheckboxes, RunCount, VictoryCount, DefeatCount
    global BtnStart, BtnStop, DdlMode
    global RobloxHwnd, GAME_TITLE

    ; Validate game window
    if (!RobloxHwnd || !DllCall("IsWindow", "Ptr", RobloxHwnd)) {
        hwnd := WinExist(GAME_TITLE)
        if !hwnd {
            MsgBox("Could not find a window matching '" GAME_TITLE "'`nPlease open Roblox first.",
                "Game Not Found", "Icon!")
            return
        }
        RobloxHwnd := hwnd
    }

    ; Read mode
    modeText := DdlMode.Text
    if (modeText == "Challenge Farming")
        OriginalFarmMode := "Challenge"
    else if (modeText == "Raid Farming")
        OriginalFarmMode := "Raid"
    else if (modeText == "Aizen Farming")
        OriginalFarmMode := "Aizen"
    else
        OriginalFarmMode := "Squadron"
    ActiveFarmMode := OriginalFarmMode

    ; Read challenge toggle
    CheckChallenge := ChkChallenges.Value
    IsCheckingChallenges := false
    LastRefreshInterval := (A_Hour * 60 + A_Min) // 30

    ; Read desired rewards
    DesiredRewards := []
    for item in RewardCheckboxes {
        if item.ctrl.Value
            DesiredRewards.Push(item.file)
    }

    ; Warn if check enabled but no rewards selected
    if (CheckChallenge && DesiredRewards.Length == 0) {
        result := MsgBox(
            "'Check challenges every 30 minutes' is enabled but no desired rewards are selected."
            . "`n`nThe macro will check but never find desired rewards."
            . "`n`nContinue anyway?",
            "No Rewards Selected", "YesNo Icon!")
        if (result == "No")
            return
    }

    ; Map dropdown selections → image filenames
    if (OriginalFarmMode == "Raid") {
        actMap := Map(
            "Hidden Danger",     "raid_act1.png",
            "Saiyan Hunt",       "raid_act2.png",
            "Ruler Dragon",      "raid_act3.png",
            "The Ultimate Evil", "raid_act4.png"
        )
        RaidActFile  := actMap[DdlRaidAct.Text]
        RaidDiffFile := (DdlRaidDiff.Text == "Hard") ? "hard_btn.png" : "normal_btn.png"
    }
    if (OriginalFarmMode == "Squadron") {
        storyMap := Map(
            "GT City",       "squadron_story1.png",
            "Marine Lobby",  "squadron_story2.png",
            "Ninja Village", "squadron_story3.png"
        )
        chapMap := Map(
            "Chapter 1", "squadron_ch1.png",
            "Chapter 2", "squadron_ch2.png",
            "Chapter 3", "squadron_ch3.png",
            "Chapter 4", "squadron_ch4.png"
        )
        SquadStoryFile := storyMap[DdlSquadStory.Text]
        SquadChapFile  := chapMap[DdlSquadChap.Text]
        SquadDiffFile  := (DdlSquadDiff.Text == "Hard") ? "hard_btn.png" : "normal_btn.png"
    }
    if (OriginalFarmMode == "Aizen") {
        AizenDiffFile := (DdlAizenDiff.Text == "Hard") ? "hard_btn.png" : "normal_btn.png"
    }

    ; Read webhook
    WebhookURL := Trim(EdtWebhook.Value)
    try IniWrite(WebhookURL, A_ScriptDir "\settings.ini", "Settings", "WebhookURL")

    ; Reset counters
    RunCount     := 0
    VictoryCount := 0
    DefeatCount  := 0

    ; Go!
    MacroRunning := true
    BtnStart.Enabled := false
    BtnStop.Enabled  := true
    PositionRobloxWindow()
    ActivateGame()
    UpdateStatus("DETECT_SCREEN", "Starting...")
    SetTimer(Tick, LOOP_INTERVAL)
}

StopMacro(*) {
    ; Kill the timer immediately so no more Ticks fire
    SetTimer(Tick, 0)
    ; Brief pause to let any in-progress Tick finish, then reload the script
    ; Reload gives a completely clean slate — all globals, statics, and state reset
    Sleep(300)
    Reload
}

; ==============================================================================
; 30-MINUTE REFRESH LOGIC
; ==============================================================================

IsAtRefreshBoundary() {
    ; Returns true if we have crossed a 30-minute boundary since the last check
    global LastRefreshInterval
    currentInterval := (A_Hour * 60 + A_Min) // 30
    if (LastRefreshInterval != -1 && currentInterval != LastRefreshInterval)
        return true
    return false
}

MarkRefreshHandled() {
    global LastRefreshInterval
    LastRefreshInterval := (A_Hour * 60 + A_Min) // 30
}

ShouldCheckChallengeNow() {
    ; Only relevant when originally farming Raid/Squadron with the toggle ON
    global OriginalFarmMode, CheckChallenge
    if (OriginalFarmMode == "Challenge")
        return false
    return CheckChallenge && IsAtRefreshBoundary()
}

ShouldLeaveChallengeForRefresh() {
    ; Only relevant when currently farming Challenge (original or temporary)
    global ActiveFarmMode
    if (ActiveFarmMode != "Challenge")
        return false
    return IsAtRefreshBoundary()
}

LeaveResultsForRefresh() {
    ; Click the post-battle "Leave" button so the macro can return to the lobby and
    ; (re-)check challenge rewards. leave_btn.png is unreliable to detect — its rounded
    ; corners pick up the constantly-changing battle-result background, so it image-matches
    ; only rarely. We therefore try the image first, then fall back to the fixed-layout
    ; position. Ground truth from logs (window at 0,0, locked to 1152x756): the Leave
    ; button center is (631,531) => 54.8% width, 70.2% height.
    ; Returns true only once the results screen is actually gone (so the caller doesn't
    ; mark the 30-min refresh handled until we have really left).
    global WIN_X, WIN_Y, WIN_W, WIN_H
    x := 0, y := 0
    if FindNav("leave_btn.png", &x, &y) {
        DebugLog("LeaveResultsForRefresh: leave_btn found at (" x "," y ") — clicking")
        ClickMultipleAt(x, y, 2, 80)
    } else {
        lx := WIN_X + (WIN_W * 548 // 1000)
        ly := WIN_Y + (WIN_H * 702 // 1000)
        DebugLog("LeaveResultsForRefresh: leave_btn not detected — coord fallback (" lx "," ly ")")
        ClickMultipleAt(lx, ly, 2, 80)
    }
    Sleep(900)

    ; Confirm we left the results screen (no retry/replay/victory/defeat still showing).
    rx := 0, ry := 0
    if FindNav("retry_btn.png", &rx, &ry)
        || FindNav("replay_btn.png", &rx, &ry, 130)
        || FindNav("victory_banner.png", &rx, &ry)
        || FindNav("defeat_banner.png", &rx, &ry) {
        DebugLog("LeaveResultsForRefresh: still on results screen — will retry next tick")
        return false
    }
    return true
}

; ==============================================================================
; IMAGE SEARCH HELPERS
; ==============================================================================

GetImageSize(path, &imgW, &imgH) {
    ; Read width & height directly from the PNG IHDR chunk header.
    ; PNG format: 8-byte signature | 4-byte length | 4-byte "IHDR" | 4-byte W | 4-byte H
    ; Width is at byte offset 16, Height at offset 20, both big-endian.
    ; This is far more reliable than DLL-based BITMAP struct parsing.
    imgW := 0, imgH := 0
    try {
        f := FileOpen(path, "r")
        if !f
            return false
        f.Seek(16)   ; skip signature(8) + chunk_length(4) + "IHDR"(4)
        ; Read width (4 bytes, big-endian)
        b1 := f.ReadUChar(), b2 := f.ReadUChar()
        b3 := f.ReadUChar(), b4 := f.ReadUChar()
        imgW := (b1 << 24) | (b2 << 16) | (b3 << 8) | b4
        ; Read height (4 bytes, big-endian)
        b1 := f.ReadUChar(), b2 := f.ReadUChar()
        b3 := f.ReadUChar(), b4 := f.ReadUChar()
        imgH := (b1 << 24) | (b2 << 16) | (b3 << 8) | b4
        f.Close()
        return (imgW > 0 && imgH > 0)
    } catch {
        imgW := 0
        imgH := 0
        return false
    }
}

FindNav(imgName, &ox, &oy, variation := -1) {
    ; Searches ONLY within the Roblox window bounds for a nav image
    ; Returns the CENTER of the matched image (not the top-left corner)
    global WIN_X, WIN_Y, WIN_W, WIN_H, IMG_VARIATION

    path := NAV_DIR imgName
    if !FileExist(path) {
        DebugLog("FindNav: FILE MISSING - " path)
        return false
    }

    baseV := (variation < 0) ? IMG_VARIATION : variation
    ; strict-then-relax:
    ; - first attempt uses a stricter tolerance
    ; - if not found, relax towards baseV
    strictV := baseV
    if (baseV > 25)
        strictV := 25
    if (baseV < strictV)
        strictV := baseV

    relaxV := baseV
    if (baseV > 25)
        relaxV := baseV

    try {
        ; Attempt #1 (strict) with TransBlack first
        result := ImageSearch(&ox, &oy, WIN_X, WIN_Y, WIN_X + WIN_W, WIN_Y + WIN_H
            , "*" strictV " *TransBlack " path)
        if !result {
            ; Attempt #1 (strict) fallback: without TransBlack
            result := ImageSearch(&ox, &oy, WIN_X, WIN_Y, WIN_X + WIN_W, WIN_Y + WIN_H
                , "*" strictV " " path)
        }

        ; Attempt #2 (relax) only if still not found and we have headroom
        if !result && (relaxV != strictV) {
            result := ImageSearch(&ox, &oy, WIN_X, WIN_Y, WIN_X + WIN_W, WIN_Y + WIN_H
                , "*" relaxV " *TransBlack " path)
            if !result {
                result := ImageSearch(&ox, &oy, WIN_X, WIN_Y, WIN_X + WIN_W, WIN_Y + WIN_H
                    , "*" relaxV " " path)
            }
        }

        if result {
            ; Offset to center of image
            imgW := 0, imgH := 0
            if GetImageSize(path, &imgW, &imgH) {
                ox += imgW // 2
                oy += imgH // 2
            }
            DebugLog("FindNav: FOUND " imgName " at center (" ox "," oy ") with variation strict=" strictV " relax=" relaxV)
            return true
        }

        DebugLog("FindNav: not found - " imgName " (searched " WIN_X "," WIN_Y " to " (WIN_X + WIN_W) "," (WIN_Y + WIN_H) " strict=" strictV " relax=" relaxV ")")
    } catch Error as e {
        DebugLog("FindNav: ERROR searching for " imgName " - " e.Message)
    }
    return false
}

FindNavInRegion(imgName, &ox, &oy, rx1, ry1, rx2, ry2, variation := -1) {
    ; Searches within specific coordinates relative to Roblox window bounds
    ; Returns the CENTER of the matched image
    global NAV_DIR, IMG_VARIATION
    path := NAV_DIR imgName
    if !FileExist(path) {
        DebugLog("FindNavInRegion: FILE MISSING - " path)
        return false
    }

    baseV := (variation < 0) ? IMG_VARIATION : variation
    strictV := baseV
    if (baseV > 25)
        strictV := 25
    if (baseV < strictV)
        strictV := baseV

    relaxV := baseV

    try {
        ; Attempt #1 (strict) with TransBlack first
        result := ImageSearch(&ox, &oy, rx1, ry1, rx2, ry2
            , "*" strictV " *TransBlack " path)
        if !result {
            result := ImageSearch(&ox, &oy, rx1, ry1, rx2, ry2
                , "*" strictV " " path)
        }

        ; Attempt #2 (relax) if needed
        if !result && (relaxV != strictV) {
            result := ImageSearch(&ox, &oy, rx1, ry1, rx2, ry2
                , "*" relaxV " *TransBlack " path)
            if !result {
                result := ImageSearch(&ox, &oy, rx1, ry1, rx2, ry2
                    , "*" relaxV " " path)
            }
        }

        if result {
            imgW := 0, imgH := 0
            if GetImageSize(path, &imgW, &imgH) {
                ox += imgW // 2
                oy += imgH // 2
            }
            DebugLog("FindNavInRegion: FOUND " imgName " at center (" ox "," oy ") in region (" rx1 "," ry1 " to " rx2 "," ry2 ") strict=" strictV " relax=" relaxV)
            return true
        }

        DebugLog("FindNavInRegion: not found - " imgName " in region (" rx1 "," ry1 " to " rx2 "," ry2 ") strict=" strictV " relax=" relaxV)
    } catch Error as e {
        DebugLog("FindNavInRegion: ERROR searching in region - " e.Message)
    }
    return false
}

FindReward(imgName, &ox, &oy) {
    ; Searches ONLY within the Roblox window bounds for a reward icon
    ; Returns the CENTER of the matched image (not the top-left corner)
    global WIN_X, WIN_Y, WIN_W, WIN_H, IMG_VARIATION
    path := REWARD_DIR imgName
    if !FileExist(path) {
        DebugLog("FindReward: File not found - " path)
        return false
    }

    baseV := IMG_VARIATION
    strictV := baseV
    if (baseV > 25)
        strictV := 25

    relaxV := baseV

    try {
        ; Attempt #1 strict
        result := ImageSearch(&ox, &oy, WIN_X, WIN_Y, WIN_X + WIN_W, WIN_Y + WIN_H, "*" strictV " " path)
        if !result && (relaxV != strictV) {
            ; Attempt #2 relax
            result := ImageSearch(&ox, &oy, WIN_X, WIN_Y, WIN_X + WIN_W, WIN_Y + WIN_H, "*" relaxV " " path)
        }

        if result {
            ; Offset to center of image
            imgW := 0, imgH := 0
            if GetImageSize(path, &imgW, &imgH) {
                ox += imgW // 2
                oy += imgH // 2
            }
            DebugLog("FindReward: FOUND " imgName " at center (" ox "," oy ") strict=" strictV " relax=" relaxV)
            return true
        }
    } catch Error as e {
        DebugLog("FindReward: ERROR searching for " imgName " - " e.Message)
    }
    return false
}

ClickAt(x, y, delay := -1) {
    global ClickCount, StateRetries

    ; Rotate through 4 offsets to ensure consecutive clicks don't hit the exact same pixel.
    ; Roblox can ignore repeated clicks on the exact same pixel.
    idx := Mod(ClickCount, 4)
    if (idx == 0) {
        jx := 1, jy := 0
    } else if (idx == 1) {
        jx := 0, jy := -1
    } else if (idx == 2) {
        jx := -1, jy := 0
    } else {
        jx := 0, jy := 1
    }
    ClickCount++

    ; Additional retry-based offset:
    ; As StateRetries grows (the next button didn't appear after a while),
    ; we shift the click position further to ensure it registers (up to 5 pixels away).
    extraOffset := 0
    if IsSet(StateRetries) {
        extraOffset := StateRetries // 2
        if (extraOffset > 5)
            extraOffset := 5
    }

    if (idx == 0) {
        jx += extraOffset
    } else if (idx == 1) {
        jy -= extraOffset
    } else if (idx == 2) {
        jx -= extraOffset
    } else {
        jy += extraOffset
    }

    cx := x + jx
    cy := y + jy

    ; Move to the click point, nudge by 1 pixel, then click.
    ; This targets cases where Roblox doesn't register the very first hover/click transition.
    MouseMove(cx, cy, 0)
    if (idx == 0) {
        MouseMove(1, 0, 0, "Relative")
    } else if (idx == 1) {
        MouseMove(0, -1, 0, "Relative")
    } else if (idx == 2) {
        MouseMove(-1, 0, 0, "Relative")
    } else {
        MouseMove(0, 1, 0, "Relative")
    }

    ; Enforce a consistent 1-pixel move/hover right before the click.
    ; This satisfies the "move by a pixel and click in the middle" behavior for
    ; both image-center clicks and coordinate fallbacks.
    MouseMove(1, 0, 0, "Relative")
    Click(cx, cy)

    if (delay < 0)
        delay := CLICK_DELAY
    if (delay > 0)
        Sleep(delay)
}


ClickFound(imgName, delay := 0) {
    ; Find and click a nav image in one call.  Returns true if found & clicked.
    x := 0, y := 0
    if FindNav(imgName, &x, &y) {
        ClickAt(x, y, delay)
        return true
    }
    return false
}

ClickMultipleAt(x, y, count := 3, interval := 150) {
    ; Clicks a screen coordinate multiple times rapidly to ensure it registers.
    ; Global jitter applies to each click.
    Loop count {
        ClickAt(x, y, interval)
    }
}

ClickMultipleFound(imgName, count := 3, interval := 150) {
    ; Finds a nav image and clicks it multiple times rapidly.
    x := 0, y := 0
    if FindNav(imgName, &x, &y) {
        ClickMultipleAt(x, y, count, interval)
        return true
    }
    return false
}

; ==============================================================================
; NAVIGATION HELPER
; ==============================================================================

NavigateToActiveMode() {
    ; Routes state machine to the correct tab based on current context
    global IsCheckingChallenges, ActiveFarmMode
    if (IsCheckingChallenges || ActiveFarmMode == "Challenge" || ActiveFarmMode == "Aizen")
        SetState("CLICK_CHALLENGE_TAB")
    else if (ActiveFarmMode == "Raid")
        SetState("CLICK_RAID_TAB")
    else
        SetState("CLICK_SQUADRON_TAB")
}

IsOnStageScreen(&ox, &oy) {
    ; Returns true if we are on the stage selection screen.
    ; Checks for the mode tabs (challenge/raid/squadron) OR the Friends Only button
    ; which also appears on that screen. Using any of these as the trigger is reliable.
    if FindNav("challenge_tab.png", &ox, &oy)
        || FindNav("raid_tab.png", &ox, &oy)
        || FindNav("squadron_tab.png", &ox, &oy)
        || FindNav("friends_only_btn.png", &ox, &oy)
        return true
    return false
}

IsOnSquadronScreen(&ox, &oy, variation := -1) {
    ; Returns true ONLY when squadron_detection.png is visible — the unique marker that
    ; appears exclusively on the squadron panel (e.g. the panel header).
    ;
    ; This is intentionally STRICT: story-entry images (GT City / Marine Lobby / Ninja
    ; Village) do NOT count as confirmation. Seeing a story name on screen is not enough —
    ; the macro must positively confirm it is on the squadron panel via this marker before
    ; clicking any story/chapter. If the marker is not found, the squadron-tab handler keeps
    ; clicking the Squadron tab until it appears.
    return FindNav("squadron_detection.png", &ox, &oy, variation)
}

IsOnChallengeScreen(&ox, &oy, variation := -1) {
    ; Returns true if the Challenge tab is currently open (i.e. the tab click succeeded).
    ; Prefers challenge_detection.png — a marker that is ONLY visible on the challenge panel
    ; (e.g. the panel header). If that asset has not been captured yet, FindNav simply
    ; returns false (logging FILE MISSING once) and we fall back to regular_challenge_btn.png.
    if FindNav("challenge_detection.png", &ox, &oy, variation)
        return true
    if FindNav("regular_challenge_btn.png", &ox, &oy, variation)
        return true
    return false
}

; ==============================================================================
; DISCORD WEBHOOK
; ==============================================================================

SendWebhook(eventType) {
    global WebhookURL, WebhookEnabled, GAME_TITLE, RobloxHwnd, WIN_X, WIN_Y, WIN_W, WIN_H
    if (!WebhookEnabled)
        return
    if (WebhookURL == "")
        return
    
    ; Ensure we have a valid webhook URL
    if (SubStr(WebhookURL, 1, 4) != "http")
        return

    tmpFile := A_Temp "\anime_squadron_" A_TickCount ".png"
    safeTmp := StrReplace(tmpFile, "'", "''")
    
    try {
        if (RobloxHwnd && DllCall("IsWindow", "Ptr", RobloxHwnd)) {
            WinActivate("ahk_id " RobloxHwnd)
            Sleep(200)
        } else if WinExist(GAME_TITLE) {
            WinActivate(GAME_TITLE)
            Sleep(200)
        }
        
        ; 1. Capture ONLY the Roblox window region (WIN_X/WIN_Y/WIN_W/WIN_H)
        psCmd := "Add-Type -AssemblyName System.Windows.Forms,System.Drawing; "
            . "$bmp = New-Object System.Drawing.Bitmap(" WIN_W ", " WIN_H "); "
            . "$g = [System.Drawing.Graphics]::FromImage($bmp); "
            . "$g.CopyFromScreen(" WIN_X ", " WIN_Y ", 0, 0, (New-Object System.Drawing.Size(" WIN_W ", " WIN_H "))); "
            . "$bmp.Save('" safeTmp "', [System.Drawing.Imaging.ImageFormat]::Png); "
            . "$g.Dispose(); $bmp.Dispose();"
        
        ; Run PowerShell to save the screenshot
        RunWait('powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "' psCmd '"',, "Hide")
        
        ; 2. Use curl.exe (standard in Win10/11) to upload to Discord Webhook
        if FileExist(tmpFile) {
            curlCmd := 'curl.exe -X POST -F "payload_json={\"content\":\"' eventType '\"}" -F "file=@' tmpFile '" "' WebhookURL '"'
            RunWait(curlCmd,, "Hide")
            try FileDelete(tmpFile)
        }
    } catch Error as e {
        DebugLog("SendWebhook Error: " e.Message)
    }
}

; ==============================================================================
; STATE MACHINE — Main Tick
; ==============================================================================

Tick() {
    global MacroRunning, State, WIN_X, WIN_Y, WIN_W, WIN_H, StateRetries, RobloxHwnd

    ; Per-tick cache for expensive ImageSearch results.
    ; Used across multiple states to avoid duplicate ImageSearch calls within the same Tick.
    global Cache_ShopIcon := false
    global Cache_PlayBtn := false, Cache_CreateRoomBtn := false, Cache_StartBtn := false

    global Cache_Victory := false, Cache_Defeat := false, Cache_Retry := false, Cache_Replay := false

    global Cache_IsOnStageScreen := false

    global Cache_ShopX := 0, Cache_ShopY := 0
    global Cache_PlayX := 0, Cache_PlayY := 0
    global Cache_CreateRoomX := 0, Cache_CreateRoomY := 0
    global Cache_StartX := 0, Cache_StartY := 0
    global Cache_VictoryX := 0, Cache_VictoryY := 0
    global Cache_DefeatX := 0, Cache_DefeatY := 0
    global Cache_RetryX := 0, Cache_RetryY := 0
    global Cache_ReplayX := 0, Cache_ReplayY := 0
    global Cache_StageX := 0, Cache_StageY := 0

    static lastRelockTick := 0
    if !MacroRunning
        return

    ; Make sure the game window exists
    if (!RobloxHwnd || !DllCall("IsWindow", "Ptr", RobloxHwnd)) {
        UpdateStatus(State, "Roblox window not found!")
        return
    }

    ; Activate Roblox if not focused
    if !IsGameActive() {
        ActivateGame()
        Sleep(300)
        return
    }

    ; Update cached Roblox window bounds for ImageSearch
    try WinGetPos(&WIN_X, &WIN_Y, &WIN_W, &WIN_H, "ahk_id " RobloxHwnd)

    ; Periodically re-lock window size in case it got resized (every ~30s).
    ; Time-based (not tick-count-based) so it stays correct regardless of LOOP_INTERVAL.
    ; A tick-count of 60 at the 50ms interval would re-lock every ~3s and cause a
    ; visible window stutter, so we gate on elapsed real time instead.
    if (lastRelockTick == 0)
        lastRelockTick := A_TickCount
    if (A_TickCount - lastRelockTick >= 30000) {
        lastRelockTick := A_TickCount
        PositionRobloxWindow()
    }

    DebugLog("Tick: State=" State " | Win bounds=(" WIN_X "," WIN_Y "," WIN_W "," WIN_H ") | Retries=" StateRetries)

    ; Populate detection cache once per tick for the active state.
    ; This prevents re-running ImageSearch multiple times when handlers call several FindNav() checks.
    if (State == "DETECT_SCREEN") {
        x := 0, y := 0

        ; 1) Lobby (shop icon)
        if FindNav("shop_icon.png", &x, &y) {
            Cache_ShopIcon := true
            Cache_ShopX := x, Cache_ShopY := y
        }

        ; 2) Battle results
        x := 0, y := 0
        if FindNav("retry_btn.png", &x, &y) {
            Cache_Retry := true
            Cache_RetryX := x, Cache_RetryY := y
        } else {
            x := 0, y := 0
            if FindNav("victory_banner.png", &x, &y) {
                Cache_Victory := true
                Cache_VictoryX := x, Cache_VictoryY := y
            } else {
                x := 0, y := 0
                if FindNav("defeat_banner.png", &x, &y) {
                    Cache_Defeat := true
                    Cache_DefeatX := x, Cache_DefeatY := y
                } else {
                    x := 0, y := 0
                    if FindNav("replay_btn.png", &x, &y, 130) {
                        Cache_Replay := true
                        Cache_ReplayX := x, Cache_ReplayY := y
                    }
                }
            }
        }

        ; 3) Stage selection
        Cache_IsOnStageScreen := IsOnStageScreen(&Cache_StageX, &Cache_StageY)
    } else if (State == "FARMING") {
        x := 0, y := 0

        if FindNav("victory_banner.png", &x, &y) {
            Cache_Victory := true, Cache_VictoryX := x, Cache_VictoryY := y
        } else if FindNav("defeat_banner.png", &x, &y) {
            Cache_Defeat := true, Cache_DefeatX := x, Cache_DefeatY := y
        } else if FindNav("retry_btn.png", &x, &y) {
            Cache_Retry := true, Cache_RetryX := x, Cache_RetryY := y
        } else if FindNav("replay_btn.png", &x, &y, 130) {
            Cache_Replay := true, Cache_ReplayX := x, Cache_ReplayY := y
        }
    } else if (State == "BATTLE_END") {
        ; Only BATTLE_END reads these caches. WAIT_RETRY does its own fresh searches,
        ; so populating the cache for it would just be redundant ImageSearch work.
        x := 0, y := 0

        if FindNav("retry_btn.png", &x, &y) {
            Cache_Retry := true, Cache_RetryX := x, Cache_RetryY := y
        } else if FindNav("replay_btn.png", &x, &y, 130) {
            Cache_Replay := true, Cache_ReplayX := x, Cache_ReplayY := y
        } else if FindNav("victory_banner.png", &x, &y) {
            Cache_Victory := true, Cache_VictoryX := x, Cache_VictoryY := y
        } else if FindNav("defeat_banner.png", &x, &y) {
            Cache_Defeat := true, Cache_DefeatX := x, Cache_DefeatY := y
        }
    }

    ; If we have been stuck in a clicking/navigation state for more than 2 ticks (1 sec),
    ; move the mouse cursor (crosshair) by 1 pixel to refresh hover states and clear image search blocking.
    if (StateRetries > 2 && State != "IDLE" && State != "FARMING" && State != "DETECT_SCREEN" && State != "CHECK_REWARDS") {
        MouseGetPos(&mx, &my)
        shift := (Mod(StateRetries, 2) == 0) ? 1 : -1
        MouseMove(mx + shift, my, 0)
        DebugLog("Tick: Stuck in state " State " (" StateRetries " retries) - Jiggled mouse cursor by " shift " pixel to (" (mx + shift) "," my ")")
    }

    switch State {
        ; ── Screen Detection ──────────────────────────────────────────────────
        case "DETECT_SCREEN":          HandleDetectScreen()

        ; ── Lobby Navigation ──────────────────────────────────────────────────
        case "CLICK_PLAY":             HandleClickPlay()
        case "CLICK_CREATE_ROOM":      HandleClickCreateRoom()

        ; ── Challenge Navigation ──────────────────────────────────────────────
        case "CLICK_CHALLENGE_TAB":    HandleClickChallengeTab()
        case "CLICK_REGULAR_CHALLENGE": HandleClickRegularChallenge()
        case "CLICK_AIZEN_CHALLENGE":   HandleClickAizenChallenge()
        case "CLICK_AIZEN_DIFF":        HandleClickAizenDiff()
        case "CHECK_REWARDS":          HandleCheckRewards()

        ; ── Raid Navigation ───────────────────────────────────────────────────
        case "CLICK_RAID_TAB":         HandleClickRaidTab()
        case "CLICK_RAID_ACT":         HandleClickRaidAct()
        case "CLICK_RAID_DIFF":        HandleClickRaidDiff()

        ; ── Squadron Navigation ───────────────────────────────────────────────
        case "CLICK_SQUADRON_TAB":     HandleClickSquadronTab()
        case "CLICK_SQUAD_STORY":      HandleClickSquadStory()
        case "CLICK_SQUAD_CHAP":       HandleClickSquadChap()
        case "CLICK_SQUAD_DIFF":       HandleClickSquadDiff()

        ; ── Stage → Battle ────────────────────────────────────────────────────
        case "CLICK_CREATE_ROOM_STAGE": HandleClickCreateRoomStage()
        case "CLICK_START":            HandleClickStart()

        ; ── In-Battle ─────────────────────────────────────────────────────────
        case "FARMING":                HandleFarming()

        ; ── Post-Battle ───────────────────────────────────────────────────────
        case "BATTLE_END":             HandleBattleEnd()
        case "WAIT_RETRY":             HandleWaitRetry()

        ; ── Challenge Detour Return ───────────────────────────────────────────
        case "RETURN_TO_MAIN_MODE":    HandleReturnToMainMode()
    }
}

; ==============================================================================
; STATE HANDLERS
; ==============================================================================

; ── Screen Detection ─────────────────────────────────────────────────────────

HandleDetectScreen() {
    global LeaveAttempts, DetectScanCount
    global Cache_ShopIcon, Cache_ShopX, Cache_ShopY
    global Cache_Retry, Cache_RetryX, Cache_RetryY
    global Cache_Victory, Cache_VictoryX, Cache_VictoryY
    global Cache_Defeat, Cache_DefeatX, Cache_DefeatY
    global Cache_Replay, Cache_ReplayX, Cache_ReplayY
    global Cache_IsOnStageScreen, Cache_StageX, Cache_StageY

    x := 0, y := 0

    DetectScanCount++
    DebugLog("=== DETECT_SCREEN scan #" DetectScanCount " ===")

    ; 1. Lobby (shop icon visible)
    if Cache_ShopIcon {
        global LastShopX, LastShopY
        LastShopX := Cache_ShopX
        LastShopY := Cache_ShopY
        UpdateStatus("DETECT_SCREEN", "Lobby detected")
        DetectScanCount := 0
        Sleep(500)
        SetState("CLICK_PLAY")
        return
    }

    ; 2. Battle results (retry / victory / defeat / replay)
    if Cache_Retry || Cache_Victory || Cache_Defeat || Cache_Replay {
        DetectScanCount := 0
        SendWebhook("🏁 STAGE END (Detected)")
        SetState("BATTLE_END")
        return
    }

    ; 3. Stage selection (tabs OR Friends Only button visible)
    if Cache_IsOnStageScreen {
        UpdateStatus("DETECT_SCREEN", "Stage menu detected")
        DetectScanCount := 0
        NavigateToActiveMode()
        return
    }

    ; 4. 3D Lobby door area (Create Room button visible = after Play was clicked)
    ; Ensure we don't falsely match inside the main lobby where shop_icon is visible.
    ; Cache_ShopIcon was already resolved this tick (and is false here, since a visible
    ; shop icon would have returned at step 1), so reuse it instead of re-searching.
    if FindNav("create_room_btn.png", &x, &y) && !Cache_ShopIcon {
        UpdateStatus("DETECT_SCREEN", "3D lobby detected")
        DetectScanCount := 0
        SetState("CLICK_CREATE_ROOM")
        return
    }

    ; 5. Play button visible directly (lobby but shop icon not matching)
    if FindNav("play_btn.png", &x, &y) {
        UpdateStatus("DETECT_SCREEN", "Play button found directly")
        DetectScanCount := 0
        SetState("CLICK_PLAY")
        return
    }

    ; 6. Start button visible — we're already inside a room
    if FindNav("start_btn.png", &x, &y) {
        UpdateStatus("DETECT_SCREEN", "Room detected — going to CLICK_START")
        DetectScanCount := 0
        SetState("CLICK_START")
        return
    }

    ; 7. Fallback: click Leave if visible (stuck between 3D lobby and stage screen)
    if FindNav("leave_btn.png", &x, &y) {
        LeaveAttempts++
        if (LeaveAttempts <= 5) {
            ClickMultipleAt(x, y, 2, 50)
            Sleep(1000)
            UpdateStatus("DETECT_SCREEN", "Clicked Leave (" LeaveAttempts "/5)...")
            return
        }
        ; Exceeded retries — stop clicking Leave, reset and keep scanning
        LeaveAttempts := 0
    }

    DebugLog("DETECT_SCREEN: No images matched on scan #" DetectScanCount)
    UpdateStatus("DETECT_SCREEN", "Scanning... (attempt " DetectScanCount ")")
    ; When nothing is on screen, this handler does ~a dozen ImageSearches per tick.
    ; Without a small pause it would re-scan every 50ms and peg the CPU for no benefit
    ; (lobby/results/stage detection does not need sub-100ms latency). Throttle gently.
    Sleep(150)
}

; ── Lobby Navigation ─────────────────────────────────────────────────────────

HandleClickPlay() {
    ; Keep clicking Play button (with 1-pixel jitter) until Create Room appears.
    ; After critical clicks, confirm next UI before transitioning state.
    global StateRetries, MAX_STATE_RETRIES, LastShopX, LastShopY, WIN_X, WIN_Y, WIN_W, WIN_H
    x := 0, y := 0
    StateRetries++

    ; 1. SUCCESS: Stage screen already visible (tabs or Friends Only button)
    if IsOnStageScreen(&x, &y) {
        DebugLog("CLICK_PLAY: stage screen already visible, navigating to mode")
        NavigateToActiveMode()
        return
    }

    ; 2. SUCCESS: Create Room button found by image — click it and transition to CLICK_CREATE_ROOM
    if FindNav("create_room_btn.png", &x, &y) {
        DebugLog("CLICK_PLAY: create_room_btn found at (" x "," y ") — clicking immediately")
        ClickAt(x, y, 1500)

        ; Confirm next UI (stage screen OR 3D-lobby create-room context)
        Sleep(800)
        if IsOnStageScreen(&x, &y) {
            NavigateToActiveMode()
            return
        }

        ; If create_room_btn still visible, retry within same state (avoid premature transitions)
        if FindNav("create_room_btn.png", &x, &y) {
            DebugLog("CLICK_PLAY: create_room_btn still visible after click — retrying (no state change)")
            return
        }

        SetState("CLICK_CREATE_ROOM")
        return
    }

    ; 3. Play button visible — click it (ClickAt automatically applies rotating 1-pixel jitter)
    if FindNav("play_btn.png", &x, &y) {
        ClickAt(x, y, 0)
        DebugLog("CLICK_PLAY: Clicked play_btn at (" x "," y ") retry=" StateRetries)
        Sleep(2000)   ; give the 3D lobby time to load

        ; Confirm we progressed: stage menu OR create room button appears
        if IsOnStageScreen(&x, &y) {
            DebugLog("CLICK_PLAY: stage screen detected after play click — navigating")
            NavigateToActiveMode()
            return
        }
        if FindNav("create_room_btn.png", &x, &y) {
            DebugLog("CLICK_PLAY: create_room_btn detected after play click — transitioning")
            SetState("CLICK_CREATE_ROOM")
            return
        }
        return
    }

    ; 4. Play button image NOT found — check where we actually are:

    ; Case A: Shop icon is visible -> We are definitely still in the main lobby!
    ; Use the shop offset fallback to click the Play button again.
    if FindNav("shop_icon.png", &x, &y) {
        LastShopX := x
        LastShopY := y
        playX := LastShopX
        playY := LastShopY + 130
        DebugLog("CLICK_PLAY: play_btn not found but shop visible — clicking shop offset (" playX "," playY ")")
        ClickAt(playX, playY, 1500)

        Sleep(1200)
        if FindNav("create_room_btn.png", &x, &y) {
            SetState("CLICK_CREATE_ROOM")
            return
        }
        return
    }

    ; Case B: Shop icon is NOT visible -> We are transitioning or already in the 3D lobby.
    ; If we've retried a few times, use the coordinate fallback for Create Room in the 3D lobby.
    if (StateRetries >= 3) {
        crX := WIN_X + (WIN_W * 48 // 100)
        crY := WIN_Y + (WIN_H * 79 // 100)
        DebugLog("CLICK_PLAY: play_btn and shop gone — coord fallback Create Room at (" crX "," crY ")")
        UpdateStatus("CLICK_PLAY", "Using coord fallback for Create Room... (" StateRetries ")")
        ClickAt(crX, crY, 1500)

        Sleep(800)
        if IsOnStageScreen(&x, &y) {
            DebugLog("CLICK_PLAY: stage screen appeared after coord fallback — navigating")
            NavigateToActiveMode()
            return
        }
        if FindNav("create_room_btn.png", &x, &y) {
            ClickAt(x, y, 1500)
            Sleep(800)
        }
        SetState("CLICK_CREATE_ROOM")
        return
    }

    ; Stuck too long — reset to screen detection
    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_PLAY: stuck for " StateRetries " retries, resetting to DETECT_SCREEN")
        SetState("DETECT_SCREEN")
        return
    }
    UpdateStatus("CLICK_PLAY", "Looking for Play or Create Room... (" StateRetries "/" MAX_STATE_RETRIES ")")
}

HandleClickCreateRoom() {
    ; Fallback loop: keep clicking Create Room (3D lobby button) until stage screen appears.
    ; After clicks, confirm stage screen before transitioning.
    global StateRetries, MAX_STATE_RETRIES, WIN_X, WIN_Y, WIN_W, WIN_H
    x := 0, y := 0
    StateRetries++

    ; SUCCESS: stage screen visible (tabs or Friends Only button)
    if IsOnStageScreen(&x, &y) {
        DebugLog("CLICK_CREATE_ROOM: stage screen detected, navigating to mode")
        NavigateToActiveMode()
        return
    }

    ; Create Room visible by image — click it
    if FindNav("create_room_btn.png", &x, &y) {
        ClickAt(x, y, 1500)
        DebugLog("CLICK_CREATE_ROOM: clicked create_room_btn at (" x "," y ") retry=" StateRetries)
        Sleep(800)

        if IsOnStageScreen(&x, &y) {
            NavigateToActiveMode()
            return
        }

        ; If create_room_btn still present, remain in this state (avoid incorrect transitions)
        if FindNav("create_room_btn.png", &x, &y) {
            DebugLog("CLICK_CREATE_ROOM: create_room_btn still visible — will retry")
            return
        }
        return
    }

    ; Image not matched — use fixed coordinate fallback (always reliable in 3D lobby)
    crX := WIN_X + (WIN_W * 48 // 100)
    crY := WIN_Y + (WIN_H * 79 // 100)
    DebugLog("CLICK_CREATE_ROOM: image not found, coord fallback (" crX "," crY ") retry=" StateRetries)
    UpdateStatus("CLICK_CREATE_ROOM", "Coord fallback for Create Room... (" StateRetries "/" MAX_STATE_RETRIES ")")
    ClickAt(crX, crY, 1500)
    Sleep(800)

    if IsOnStageScreen(&x, &y) {
        DebugLog("CLICK_CREATE_ROOM: stage screen appeared after coord fallback")
        NavigateToActiveMode()
        return
    }

    ; Stuck too long — go back to detection
    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_CREATE_ROOM: stuck for " StateRetries " ticks, resetting to DETECT_SCREEN")
        SetState("DETECT_SCREEN")
        return
    }
    UpdateStatus("CLICK_CREATE_ROOM", "Waiting for stage screen... (" StateRetries "/" MAX_STATE_RETRIES ")")
}

; ── Challenge Flow ───────────────────────────────────────────────────────────

HandleClickChallengeTab() {
    global StateRetries, MAX_STATE_RETRIES, WIN_X, WIN_Y, WIN_W, WIN_H
    global IsCheckingChallenges, ActiveFarmMode
    x := 0, y := 0
    StateRetries++

    ; Already on challenge screen (challenge_detection marker or regular challenge btn visible)?
    if IsOnChallengeScreen(&x, &y) {
        DebugLog("CLICK_CHALLENGE_TAB: already on challenge screen")
        if (ActiveFarmMode == "Aizen" && !IsCheckingChallenges) {
            DebugLog("CLICK_CHALLENGE_TAB: challenge screen confirmed — switching to CLICK_AIZEN_CHALLENGE")
            SetState("CLICK_AIZEN_CHALLENGE")
        } else {
            DebugLog("CLICK_CHALLENGE_TAB: challenge screen confirmed — switching to CLICK_REGULAR_CHALLENGE")
            SetState("CLICK_REGULAR_CHALLENGE")
        }
        return
    }

    ; Click the challenge tab, re-checking after EVERY click so we STOP the instant the
    ; challenge panel is confirmed via challenge_detection.png. This replaces the old
    ; behaviour of blindly clicking the tab 3x in a row, which kept clicking even after the
    ; panel had opened and could re-toggle the tab back off.
    ctx := 0, cty := 0
    if FindNav("challenge_tab.png", &ctx, &cty) {
        DebugLog("CLICK_CHALLENGE_TAB: FOUND challenge_tab.png at (" ctx "," cty ") — clicking until panel detected")
        detected := false
        Loop 3 {
            ClickAt(ctx, cty, 150)

            ; Stop the moment challenge_detection.png (preferred) confirms the panel is open.
            dx := 0, dy := 0
            if IsOnChallengeScreen(&dx, &dy, 60) {
                DebugLog("CLICK_CHALLENGE_TAB: challenge panel detected after click — stopping tab clicks")
                detected := true
                break
            }
            Sleep(200)
        }

        ; If the panel renders a touch late, give it one short grace check before deciding.
        if !detected {
            Sleep(400)
            dx := 0, dy := 0
            detected := IsOnChallengeScreen(&dx, &dy, 60)
        }

        if detected {
            if (ActiveFarmMode == "Aizen" && !IsCheckingChallenges) {
                DebugLog("CLICK_CHALLENGE_TAB: challenge screen confirmed — switching to CLICK_AIZEN_CHALLENGE")
                SetState("CLICK_AIZEN_CHALLENGE")
            } else {
                DebugLog("CLICK_CHALLENGE_TAB: challenge screen confirmed — switching to CLICK_REGULAR_CHALLENGE")
                SetState("CLICK_REGULAR_CHALLENGE")
            }
            return
        }

        DebugLog("CLICK_CHALLENGE_TAB: clicked challenge_tab but panel not confirmed — will retry tab")
        return
    }

    ; Coordinate fallback (only after image search fails):
    ; Challenge tab sits between Squadron and Raid, so use a mid-X anchor and
    ; verify via IsOnChallengeScreen before switching state.
    if (StateRetries > 2) {
        ; Mid anchor: between raid/squadron right-side (~735/1000) and left/middle.
        ctX := WIN_X + (WIN_W * 60 // 100)   ; ~60% width => between tabs
        ctY := WIN_Y + (WIN_H * 83 // 100)   ; middle-ish Y like tab center

        DebugLog("CLICK_CHALLENGE_TAB: image not found — coord fallback mid between tabs (" ctX "," ctY ") retry=" StateRetries)
        UpdateStatus("CLICK_CHALLENGE_TAB", "Coord fallback (mid-between) then verify... (" StateRetries "/" MAX_STATE_RETRIES ")")

        ; Small Y sweep around center to hit the actual tab area.
        yOffsets := [-(WIN_H * 2 // 100), 0, (WIN_H * 2 // 100)]
        Loop 2 { ; two rounds
            for i, dy in yOffsets {
                ClickAt(ctX, ctY + dy, 600)

                tx := 0, ty := 0
                if IsOnChallengeScreen(&tx, &ty, 45) {
                    DebugLog("CLICK_CHALLENGE_TAB: challenge screen confirmed after coord fallback at (" tx "," ty ")")
                    Sleep(350)

                    if (ActiveFarmMode == "Aizen" && !IsCheckingChallenges) {
                        DebugLog("CLICK_CHALLENGE_TAB: coord fallback confirmed — switching to CLICK_AIZEN_CHALLENGE")
                        SetState("CLICK_AIZEN_CHALLENGE")
                    } else {
                        DebugLog("CLICK_CHALLENGE_TAB: coord fallback confirmed — switching to CLICK_REGULAR_CHALLENGE")
                        SetState("CLICK_REGULAR_CHALLENGE")
                    }
                    return
                }
            }
        }

        DebugLog("CLICK_CHALLENGE_TAB: coord fallback did not confirm challenge screen — resetting")
        SetState("DETECT_SCREEN")
        return
    }

    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_CHALLENGE_TAB: stuck (no challenge_tab match), resetting")
        SetState("DETECT_SCREEN")
        return
    }

    UpdateStatus("CLICK_CHALLENGE_TAB", "Looking for Challenge tab... (" StateRetries "/" MAX_STATE_RETRIES ")")
}

HandleClickRegularChallenge() {
    global IsCheckingChallenges, StateRetries, MAX_STATE_RETRIES, WIN_X, WIN_Y, WIN_W, WIN_H
    StateRetries++

    ; Pre-check: we must be on the challenge panel; otherwise re-click the challenge tab.
    x0 := 0, y0 := 0
    if !IsOnChallengeScreen(&x0, &y0, 60) {
        DebugLog("CLICK_REGULAR_CHALLENGE: challenge panel not detected — going back to CLICK_CHALLENGE_TAB")
        SetState("CLICK_CHALLENGE_TAB")
        return
    }

    x := 0, y := 0

    ; IMPORTANT: Do NOT check create_room_stage_btn here as a skip condition.
    ; The Create Room button is ALWAYS visible in the challenge panel (for Daily Challenge too).
    ; We must always explicitly click the Regular Challenge entry to select it.

    ; Search ONLY in the challenge stage selection panel region (left-middle area)
    x1 := WIN_X + (WIN_W * 20 // 100)
    y1 := WIN_Y + (WIN_H * 25 // 100)
    x2 := WIN_X + (WIN_W * 45 // 100)
    y2 := WIN_Y + (WIN_H * 55 // 100)
    if FindNavInRegion("regular_challenge_btn.png", &x, &y, x1, y1, x2, y2, 50) {
        ClickMultipleAt(x, y, 2, 50)
        DebugLog("CLICK_REGULAR_CHALLENGE: clicked regular_challenge_btn 2x at (" x "," y ")")
        Sleep(1200)
        if IsCheckingChallenges
            SetState("CHECK_REWARDS")
        else
            SetState("CLICK_CREATE_ROOM_STAGE")
        return
    }

    ; First attempt is image-only: give regular_challenge_btn.png a clean shot before we
    ; resort to coordinates. The coordinate fallback is queued for the NEXT tick — it only
    ; fires once this first image attempt has already failed (StateRetries >= 2). This avoids
    ; blindly clicking a fixed spot when the image would have matched a moment later.
    if (StateRetries < 2) {
        DebugLog("CLICK_REGULAR_CHALLENGE: image not found on first attempt — retrying image before coord fallback")
        UpdateStatus("CLICK_REGULAR_CHALLENGE", "Looking for Regular Challenge (image)... (" StateRetries "/" MAX_STATE_RETRIES ")")
        return
    }

    ; Image still not found after the first attempt — use coordinate fallback (relative to
    ; the locked 1152x756 window).
    ; Ground truth from the live macro window: the "Regular Challenge" entry is the MIDDLE
    ; of the three stage entries in the LEFT column of the challenge panel — Daily Challenge
    ; sits above it, Katakara Bridge (Aizen) sits below it. Its center is ~ (384,333) =>
    ; 33.3% width, 44% height.
    ; NOTE: the previous Y (48% / ~362px) landed in the gap just *below* Regular Challenge and
    ; could clip Katakara Bridge — which would wrongly start Aizen. 44% centers on the button.
    rcX := WIN_X + (WIN_W * 333 // 1000)   ; ~384 px
    rcY := WIN_Y + (WIN_H * 440 // 1000)   ; ~333 px
    DebugLog("CLICK_REGULAR_CHALLENGE: image not found in region, coord fallback (" rcX "," rcY ") retry=" StateRetries)
    UpdateStatus("CLICK_REGULAR_CHALLENGE", "Coord fallback for Regular Challenge... (" StateRetries "/" MAX_STATE_RETRIES ")")
    ClickMultipleAt(rcX, rcY, 3, 150)
    Sleep(1200)
    ; After clicking the entry, proceed — Regular Challenge is now selected
    if IsCheckingChallenges
        SetState("CHECK_REWARDS")
    else
        SetState("CLICK_CREATE_ROOM_STAGE")
    return
}

HandleCheckRewards() {
    global DesiredRewards, IsCheckingChallenges, ActiveFarmMode, OriginalFarmMode
    UpdateStatus("CHECK_REWARDS", "Scanning reward icons...")
    Sleep(1500)   ; wait for reward icons to fully render

    found := false
    x := 0, y := 0
    for rewardFile in DesiredRewards {
        if FindReward(rewardFile, &x, &y) {
            found := true
            UpdateStatus("CHECK_REWARDS", "Desired reward found: " rewardFile)
            DebugLog("CHECK_REWARDS: Found desired reward: " rewardFile)
            break
        }
    }

    IsCheckingChallenges := false

    if found {
        ; Desired reward available — switch to challenge farming
        ActiveFarmMode := "Challenge"
        UpdateStatus("CHECK_REWARDS", "Switching to Challenge farming!")
        SetState("CLICK_CREATE_ROOM_STAGE")
    } else {
        ; No desired rewards — return to original farming mode
        UpdateStatus("CHECK_REWARDS", "No desired rewards → returning to " OriginalFarmMode)
        DebugLog("CHECK_REWARDS: No rewards found, returning to " OriginalFarmMode)
        SetState("RETURN_TO_MAIN_MODE")
    }
}

HandleClickAizenChallenge() {
    global StateRetries, MAX_STATE_RETRIES, WIN_X, WIN_Y, WIN_W, WIN_H
    StateRetries++

    ; Pre-check: we must be on the challenge panel; otherwise re-click the challenge tab.
    x0 := 0, y0 := 0
    if !IsOnChallengeScreen(&x0, &y0, 60) {
        DebugLog("CLICK_AIZEN_CHALLENGE: challenge panel not detected — going back to CLICK_CHALLENGE_TAB")
        SetState("CLICK_CHALLENGE_TAB")
        return
    }

    x := 0, y := 0

    ; Search ONLY in the challenge stage selection panel region (left-middle area)
    x1 := WIN_X + (WIN_W * 20 // 100)
    y1 := WIN_Y + (WIN_H * 25 // 100)
    x2 := WIN_X + (WIN_W * 45 // 100)
    y2 := WIN_Y + (WIN_H * 80 // 100) ; increased y2 to account for bottom
    if FindNavInRegion("aizen_btn.png", &x, &y, x1, y1, x2, y2, 50) {
        ClickMultipleAt(x, y, 2, 50)
        DebugLog("CLICK_AIZEN_CHALLENGE: clicked aizen_btn 2x at (" x "," y ")")
        Sleep(1200)
        SetState("CLICK_AIZEN_DIFF")
        return
    }

    ; Image not found — use coordinate fallback.
    if (StateRetries > 2) {
        cbrX := WIN_X + (WIN_W * 30 // 100)    ; ~340 px
        cbrY := WIN_Y + (WIN_H * 65 // 100)    ; approx katakara bridge y pos
        DebugLog("CLICK_AIZEN_CHALLENGE: image not found in region, coord fallback (" cbrX "," cbrY ") retry=" StateRetries)
        UpdateStatus("CLICK_AIZEN_CHALLENGE", "Coord fallback for Aizen Challenge... (" StateRetries "/" MAX_STATE_RETRIES ")")
        ClickMultipleAt(cbrX, cbrY, 3, 150)
        Sleep(1200)
        SetState("CLICK_AIZEN_DIFF")
        return
    }

    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_AIZEN_CHALLENGE: stuck, resetting")
        SetState("DETECT_SCREEN")
        return
    }
    UpdateStatus("CLICK_AIZEN_CHALLENGE", "Looking for Aizen Challenge... (" StateRetries "/" MAX_STATE_RETRIES ")")
}

HandleClickAizenDiff() {
    global AizenDiffFile, StateRetries, MAX_STATE_RETRIES, WIN_X, WIN_Y, WIN_W, WIN_H
    x := 0, y := 0
    StateRetries++

    ; Normal difficulty is selected by default when a stage is opened, so there is no
    ; button to press — go straight to creating the room. Only Hard needs an explicit click.
    if (AizenDiffFile == "normal_btn.png") {
        DebugLog("CLICK_AIZEN_DIFF: Normal is default — skipping difficulty click, going to Create Room")
        SetState("CLICK_CREATE_ROOM_STAGE")
        return
    }

    x1 := WIN_X + (WIN_W * 50 // 100)
    y1 := WIN_Y + (WIN_H * 40 // 100)
    x2 := WIN_X + (WIN_W * 90 // 100)
    y2 := WIN_Y + (WIN_H * 70 // 100)
    
    ; First try image-detection in the Aizen difficulty panel region.
    ; After a successful click, confirm the selected difficulty is actually visible.
    if (FindNavInRegion(AizenDiffFile, &x, &y, x1, y1, x2, y2, 40)) {
        ClickMultipleAt(x, y, 2, 50)
        DebugLog("CLICK_AIZEN_DIFF: clicked " AizenDiffFile " at (" x "," y ") (image-based)")
        Sleep(900)

        ; Confirm the difficulty is now present (prevents wrong-option clicks).
        tx := 0, ty := 0
        if (FindNavInRegion(AizenDiffFile, &tx, &ty, x1, y1, x2, y2, 60)) {
            DebugLog("CLICK_AIZEN_DIFF: confirmed via image after click: " AizenDiffFile " at (" tx "," ty ")")
            SetState("CLICK_CREATE_ROOM_STAGE")
            return
        }

        ; Secondary: allow proceed if Create Room (stage) already became visible.
        ; This avoids getting stuck if the confirm image is flaky.
        sx := 0, sy := 0
        if FindNav("create_room_stage_btn.png", &sx, &sy) {
            DebugLog("CLICK_AIZEN_DIFF: create_room_stage_btn detected after difficulty click")
            SetState("CLICK_CREATE_ROOM_STAGE")
            return
        }

        DebugLog("CLICK_AIZEN_DIFF: image click did not confirm — will use coord fallback next ticks")
    }

    ; Coordinate fallback (Aizen-specific; keep raid flow unaffected)
    if (StateRetries > 2) {
        isHard := (AizenDiffFile == "hard_btn.png")

        ; Aizen difficulty buttons sit closer to the Aizen challenge panel.
        ; Use a left-ish anchor and separate Y anchors for Normal vs Hard.
        aizenX := WIN_X + (WIN_W * 52 // 100) ; distinct from raid diff column (~right side)
        aizenNormalY := WIN_Y + (WIN_H * 54 // 100)
        aizenHardY   := WIN_Y + (WIN_H * 59 // 100)
        fbX := aizenX
        fbY := isHard ? aizenHardY : aizenNormalY

        DebugLog("CLICK_AIZEN_DIFF: image not found — fallback (" fbX "," fbY ") retry=" StateRetries)
        UpdateStatus("CLICK_AIZEN_DIFF", "Coord fallback for Aizen diff... (" StateRetries "/" MAX_STATE_RETRIES ")")

        ; Confirm within the Aizen difficulty panel region to avoid false matches (like rewards area).
        rx1 := WIN_X + (WIN_W * 45 // 100)
        ry1 := WIN_Y + (WIN_H * 40 // 100)
        rx2 := WIN_X + (WIN_W * 80 // 100)
        ry2 := WIN_Y + (WIN_H * 70 // 100)

        Loop 2 {
            ClickMultipleAt(fbX, fbY, 2, 150)
            Sleep(800)

            xT := 0, yT := 0
            if FindNavInRegion(AizenDiffFile, &xT, &yT, rx1, ry1, rx2, ry2, 60) {
                DebugLog("CLICK_AIZEN_DIFF: confirmed via image (Aizen region) " AizenDiffFile " at (" xT "," yT ") after fallback")
                SetState("CLICK_CREATE_ROOM_STAGE")
                return
            }
            ; If stage already opened, proceed.
            if FindNav("create_room_stage_btn.png", &xT, &yT) {
                DebugLog("CLICK_AIZEN_DIFF: create_room_stage_btn detected after fallback — proceeding")
                SetState("CLICK_CREATE_ROOM_STAGE")
                return
            }
        }

        DebugLog("CLICK_AIZEN_DIFF: fallback did not confirm image " AizenDiffFile " — staying in state")
        UpdateStatus("CLICK_AIZEN_DIFF", "Waiting for difficulty selection to confirm...")
        return
    }



    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_AIZEN_DIFF: stuck, resetting")
        SetState("DETECT_SCREEN")
        return
    }

    UpdateStatus("CLICK_AIZEN_DIFF", "Looking for Aizen difficulty... (" StateRetries "/" MAX_STATE_RETRIES ")")
}

; ── Raid Flow ────────────────────────────────────────────────────────────────

HandleClickRaidTab() {
    global StateRetries, MAX_STATE_RETRIES, WIN_X, WIN_Y, WIN_W, WIN_H
    x := 0, y := 0
    StateRetries++

    ; Already on raid screen (act list visible)?
    if FindNav("raid_act1.png", &x, &y)
        || FindNav("raid_act2.png", &x, &y)
        || FindNav("raid_act3.png", &x, &y)
        || FindNav("raid_act4.png", &x, &y) {
        DebugLog("CLICK_RAID_TAB: already on raid screen")
        SetState("CLICK_RAID_ACT")
        return
    }

    ; Slower raid-tab clicking to avoid misclicking other buttons that appear nearby.
    rx := 0, ry := 0
    if FindNav("raid_tab.png", &rx, &ry, 40) {
        DebugLog("CLICK_RAID_TAB: FOUND raid_tab.png at (" rx "," ry ") — slower click to avoid misclicks")
        Loop 3 {
            ClickAt(rx, ry, 500) ; slower than 150ms
            Sleep(250)
        }
        Sleep(1200)

        ; Confirm we landed on raid screen (act list appears)
        ax := 0, ay := 0
        if FindNav("raid_act1.png", &ax, &ay, 60)
            || FindNav("raid_act2.png", &ax, &ay, 60)
            || FindNav("raid_act3.png", &ax, &ay, 60)
            || FindNav("raid_act4.png", &ax, &ay, 60) {
            SetState("CLICK_RAID_ACT")
            return
        }
    }

    ; Coordinate fallback: if image not found after a few retries, click the tab by coordinates
    if (StateRetries > 2) {
        rtX := WIN_X + (WIN_W * 735 // 1000)  ; ~847 px
        rtY := WIN_Y + (WIN_H * 79 // 100)    ; ~597 px
        DebugLog("CLICK_RAID_TAB: image not found, coord fallback (" rtX "," rtY ") retry=" StateRetries)
        UpdateStatus("CLICK_RAID_TAB", "Coord fallback for Raid tab... (" StateRetries "/" MAX_STATE_RETRIES ")")

        Loop 3 {
            ClickAt(rtX, rtY, 600)
            Sleep(300)
        }
        Sleep(1200)

        SetState("CLICK_RAID_ACT")
        return
    }

    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_RAID_TAB: stuck, resetting")
        SetState("DETECT_SCREEN")
        return
    }
    UpdateStatus("CLICK_RAID_TAB", "Looking for Raid tab... (" StateRetries ")")
}

HandleClickRaidAct() {
    global RaidActFile, StateRetries, MAX_STATE_RETRIES, WIN_X, WIN_Y, WIN_W, WIN_H
    StateRetries++
    if ClickMultipleFound(RaidActFile, 3, 150) {
        Sleep(800)
        SetState("CLICK_RAID_DIFF")
        return
    }

    ; Coordinate fallback for raid act selection (helps when raid_act*.png image matching fails)
    if (StateRetries > 2) {
        ; Map raid_act1..4.png → approximate vertical positions within the raid act list panel.
        actIndex := 1
        if (RaidActFile == "raid_act2.png")
            actIndex := 2
        else if (RaidActFile == "raid_act3.png")
            actIndex := 3
        else if (RaidActFile == "raid_act4.png")
            actIndex := 4

        ; Narrower x guess, then sweep y slightly until we confirm the expected act image.
        actX := WIN_X + (WIN_W * 49 // 100)
        baseActY := WIN_Y + (WIN_H * (28 + (actIndex - 1) * 13) // 100)

        DebugLog("CLICK_RAID_ACT: image not found, coord fallback base (" actX "," baseActY ") for " RaidActFile " retry=" StateRetries)
        UpdateStatus("CLICK_RAID_ACT", "Coord fallback for " RaidActFile "... (" StateRetries "/" MAX_STATE_RETRIES ")")

        offsets := [0, -(WIN_H * 2 // 100), (WIN_H * 2 // 100)]
        Loop offsets.Length {
            dy := offsets[A_Index]
            ClickMultipleAt(actX, baseActY + dy, 2, 150)
            Sleep(700)

            xT := 0, yT := 0
            if FindNav(RaidActFile, &xT, &yT, 60) {
                DebugLog("CLICK_RAID_ACT: confirmed act via image " RaidActFile " at (" xT "," yT ") after coord fallback")
                SetState("CLICK_RAID_DIFF")
                return
            }
        }

        DebugLog("CLICK_RAID_ACT: coord fallback did not confirm act via image " RaidActFile " — staying in state for retry")
        ; Let the handler loop naturally (do not force SetState).
        UpdateStatus("CLICK_RAID_ACT", "Waiting for act selection to confirm...")
        return
    }

    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_RAID_ACT: stuck, resetting")
        SetState("DETECT_SCREEN")
        return
    }
    UpdateStatus("CLICK_RAID_ACT", "Looking for " RaidActFile "... (" StateRetries ")")
}

GetRobloxQuadrant() {
    ; Returns one of: "TL","TR","BL","BR" based on Roblox window center.
    global WIN_X, WIN_Y, WIN_W, WIN_H, SCREEN_W, SCREEN_H
    cx := WIN_X + (WIN_W // 2)
    cy := WIN_Y + (WIN_H // 2)

    midX := SCREEN_W // 2
    midY := SCREEN_H // 2

    if (cx < midX) {
        return (cy < midY) ? "TL" : "BL"
    } else {
        return (cy < midY) ? "TR" : "BR"
    }
}

RaidDiffCoordFallback(isHard) {
    ; Coordinate fallback for the difficulty buttons, returned as "x,y" screen coords.
    ; The window is always forced to a fixed 1152x756 size, so window-relative percentages
    ; are stable no matter where the window sits on screen — the old screen-quadrant
    ; adjustment actually shifted this fixed position by up to ~11px and is removed.
    ;
    ; Ground truth from logs (window-relative on the locked layout):
    ;   Hard button center   ≈ (821,410)  => 71.3% width, 54.2% height
    ;   Normal button center ≈ (782,391)  => 67.9% width, 51.7% height
    ; In practice Normal is now skipped (it is selected by default), so only the Hard
    ; anchor is used — but both are kept distinct so a Hard click never lands on Normal.
    global WIN_X, WIN_Y, WIN_W, WIN_H

    if (isHard) {
        diffX := WIN_X + (WIN_W * 713 // 1000)   ; ~821 px
        diffY := WIN_Y + (WIN_H * 542 // 1000)   ; ~410 px
    } else {
        diffX := WIN_X + (WIN_W * 679 // 1000)   ; ~782 px
        diffY := WIN_Y + (WIN_H * 517 // 1000)   ; ~391 px
    }

    return diffX "," diffY
}

HandleClickRaidDiff() {
    global RaidDiffFile, StateRetries, MAX_STATE_RETRIES
    x := 0, y := 0
    StateRetries++

    ; Normal difficulty is selected by default when a stage is opened, so there is no
    ; button to press — go straight to creating the room. Only Hard needs an explicit click.
    if (RaidDiffFile == "normal_btn.png") {
        DebugLog("CLICK_RAID_DIFF: Normal is default — skipping difficulty click, going to Create Room")
        SetState("CLICK_CREATE_ROOM_STAGE")
        return
    }

    ; If Create Room (stage) already visible, difficulty is already selected
    if FindNav("create_room_stage_btn.png", &x, &y) {
        DebugLog("CLICK_RAID_DIFF: create_room_stage_btn already visible, skipping diff click")
        SetState("CLICK_CREATE_ROOM_STAGE")
        return
    }

    if ClickMultipleFound(RaidDiffFile, 3, 150) {
        Sleep(800)
        SetState("CLICK_CREATE_ROOM_STAGE")
        return
    }

    ; Coordinate fallback when images fail:
    ; If NORMAL is selected, do NOT click any difficulty button fallback
    ; (normal should not need an extra selection; clicking can switch to Hard by mistake).
    ; Only do coord fallback when HARD is selected.
    if (StateRetries > 2) {
        if (RaidDiffFile == "hard_btn.png") {
            isHard := true
            coordStr := RaidDiffCoordFallback(isHard)
            parts := StrSplit(coordStr, ",")
            fbX := parts[1]
            fbY := parts[2]

            DebugLog("CLICK_RAID_DIFF: image not found — HARD coord fallback (" fbX "," fbY ") retry=" StateRetries)
            UpdateStatus("CLICK_RAID_DIFF", "Coord fallback for Raid HARD... (" StateRetries "/" MAX_STATE_RETRIES ")")

            Loop 2 {
                ClickMultipleAt(fbX, fbY, 2, 150)
                Sleep(700)

                xT := 0, yT := 0
                if FindNav(RaidDiffFile, &xT, &yT, 60) {
                    DebugLog("CLICK_RAID_DIFF: confirmed difficulty selected via image " RaidDiffFile " at (" xT "," yT ")")
                    SetState("CLICK_CREATE_ROOM_STAGE")
                    return
                }
            }
        } else {
            DebugLog("CLICK_RAID_DIFF: difficulty image not found, but NORMAL is selected — skipping coord fallback to avoid switching to HARD")
            UpdateStatus("CLICK_RAID_DIFF", "Waiting for stage after NORMAL selection... (" StateRetries "/" MAX_STATE_RETRIES ")")
        }

        ; If stage is already available, proceed.
        if FindNav("create_room_stage_btn.png", &x, &y) {
            DebugLog("CLICK_RAID_DIFF: create_room_stage_btn detected, proceeding")
            SetState("CLICK_CREATE_ROOM_STAGE")
            return
        }
    }

    ; After half max retries without finding diff btn, check if Create Room appeared anyway
    ; (handles cases where normal_btn/hard_btn images are not ideal matches)
    if (StateRetries >= MAX_STATE_RETRIES // 2) {
        if FindNav("create_room_stage_btn.png", &x, &y) {
            DebugLog("CLICK_RAID_DIFF: create_room_stage_btn appeared after retries, proceeding")
            SetState("CLICK_CREATE_ROOM_STAGE")
            return
        }
    }

    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_RAID_DIFF: stuck, resetting")
        SetState("DETECT_SCREEN")
        return
    }
    UpdateStatus("CLICK_RAID_DIFF", "Looking for difficulty... (" StateRetries "/" MAX_STATE_RETRIES ")")
}

; ── Squadron Flow ────────────────────────────────────────────────────────────

HandleClickSquadronTab() {
    global StateRetries, MAX_STATE_RETRIES, WIN_X, WIN_Y, WIN_W, WIN_H
    x := 0, y := 0
    StateRetries++

    ; Already confirmed on squadron panel (squadron_detection.png marker visible)?
    if IsOnSquadronScreen(&x, &y) {
        DebugLog("CLICK_SQUADRON_TAB: already on squadron screen")
        SetState("CLICK_SQUAD_STORY")
        return
    }

    ; Slower squadron-tab clicking to avoid misclicking above/beside tabs.
    sx := 0, sy := 0
    if FindNav("squadron_tab.png", &sx, &sy, 40) {
        DebugLog("CLICK_SQUADRON_TAB: FOUND squadron_tab.png at (" sx "," sy ") — slower click to avoid misclicks")
        Loop 3 {
            ClickAt(sx, sy, 500)
            Sleep(250)
        }
        Sleep(1200)

        xT := 0, yT := 0
        if IsOnSquadronScreen(&xT, &yT, 60) {
            DebugLog("CLICK_SQUADRON_TAB: confirmed squadron screen after direct click")
            SetState("CLICK_SQUAD_STORY")
            return
        }
    }

    ; Coordinate fallback: if image not found after a few retries, click the tab by coordinates and confirm
    if (StateRetries > 2) {
        ; Use the same stable anchor style as raid tab coords (avoid incorrect quadrant math here).
        stX := WIN_X + (WIN_W * 735 // 1000)  ; ~847 px
        stY := WIN_Y + (WIN_H * 79 // 100)    ; ~597 px

        DebugLog("CLICK_SQUADRON_TAB: image not found, coord fallback (" stX "," stY ") retry=" StateRetries)
        UpdateStatus("CLICK_SQUADRON_TAB", "Coord fallback for Squadron tab... (" StateRetries "/" MAX_STATE_RETRIES ")")

        Loop 2 {
            Loop 3 {
                ClickAt(stX, stY, 600)
                Sleep(300)
            }
            Sleep(900)

            xT := 0, yT := 0
            if IsOnSquadronScreen(&xT, &yT, 60) {
                DebugLog("CLICK_SQUADRON_TAB: confirmed squadron screen after fallback")
                SetState("CLICK_SQUAD_STORY")
                return
            }
        }

        DebugLog("CLICK_SQUADRON_TAB: fallback did not confirm squadron screen — staying in state")
        UpdateStatus("CLICK_SQUADRON_TAB", "Waiting for squadron screen to confirm...")
        return
    }

    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_SQUADRON_TAB: stuck, resetting")
        SetState("DETECT_SCREEN")
        return
    }
    UpdateStatus("CLICK_SQUADRON_TAB", "Looking for Squadron tab... (" StateRetries ")")
}

HandleClickSquadStory() {
    global SquadStoryFile, StateRetries, MAX_STATE_RETRIES, WIN_X, WIN_Y, WIN_W, WIN_H
    StateRetries++

    ; Pre-check: we must be on the squadron panel; otherwise re-click the squadron tab.
    x0 := 0, y0 := 0
    if !IsOnSquadronScreen(&x0, &y0, 60) {
        DebugLog("CLICK_SQUAD_STORY: squadron panel not detected — going back to CLICK_SQUADRON_TAB")
        SetState("CLICK_SQUADRON_TAB")
        return
    }

    ; Primary: click the selected story image and confirm it is present after click.
    if ClickMultipleFound(SquadStoryFile, 3, 150) {
        Sleep(1000)
        xC := 0, yC := 0
        if FindNav(SquadStoryFile, &xC, &yC, 60) {
            DebugLog("CLICK_SQUAD_STORY: confirmed selected story via " SquadStoryFile " at (" xC "," yC ")")
            SetState("CLICK_SQUAD_CHAP")
            return
        }
        ; If click landed but image match is flaky, still allow proceed only if the other story list remains (prevents wrong mode).
        DebugLog("CLICK_SQUAD_STORY: story click executed but " SquadStoryFile " not confirmed — retrying within state")
    }

    if (StateRetries > 2) {
        ; story1..3 map to three vertical entries; use raid-style right-side anchor + y sweep.
        storyIndex := 1
        if (SquadStoryFile == "squadron_story2.png")
            storyIndex := 2
        else if (SquadStoryFile == "squadron_story3.png")
            storyIndex := 3

        sX := WIN_X + (WIN_W * 49 // 100)
        baseSY := WIN_Y + (WIN_H * (28 + (storyIndex - 1) * 16) // 100)

        DebugLog("CLICK_SQUAD_STORY: image not found — coord fallback base (" sX "," baseSY ") retry=" StateRetries)
        UpdateStatus("CLICK_SQUAD_STORY", "Coord fallback for Squadron story... (" StateRetries "/" MAX_STATE_RETRIES ")")

        offsets := [0, -(WIN_H * 1 // 100), (WIN_H * 1 // 100)]
        Loop offsets.Length {
            dy := offsets[A_Index]
            ClickMultipleAt(sX, baseSY + dy, 2, 150)
            Sleep(700)

            xT := 0, yT := 0
            if FindNav(SquadStoryFile, &xT, &yT, 60) {
                DebugLog("CLICK_SQUAD_STORY: confirmed via image " SquadStoryFile " at (" xT "," yT ") after fallback")
                SetState("CLICK_SQUAD_CHAP")
                return
            }
        }

        DebugLog("CLICK_SQUAD_STORY: fallback did not confirm " SquadStoryFile " — staying in state")
        UpdateStatus("CLICK_SQUAD_STORY", "Waiting for story selection to confirm...")
        return
    }

    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_SQUAD_STORY: stuck, resetting")
        SetState("DETECT_SCREEN")
        return
    }
    UpdateStatus("CLICK_SQUAD_STORY", "Looking for story button... (" StateRetries ")")
}

HandleClickSquadChap() {
    global SquadChapFile, StateRetries, MAX_STATE_RETRIES, WIN_X, WIN_Y, WIN_W, WIN_H
    StateRetries++

    if ClickMultipleFound(SquadChapFile, 3, 150) {
        Sleep(1000)
        SetState("CLICK_SQUAD_DIFF")
        return
    }

    if (StateRetries > 2) {
        ; ch1..4 map to four vertical entries; use same relative approach as raid acts.
        chapIndex := 1
        if (SquadChapFile == "squadron_ch2.png")
            chapIndex := 2
        else if (SquadChapFile == "squadron_ch3.png")
            chapIndex := 3
        else if (SquadChapFile == "squadron_ch4.png")
            chapIndex := 4

        cX := WIN_X + (WIN_W * 49 // 100)
        baseCY := WIN_Y + (WIN_H * (28 + (chapIndex - 1) * 10) // 100)

        DebugLog("CLICK_SQUAD_CHAP: image not found — coord fallback base (" cX "," baseCY ") retry=" StateRetries)
        UpdateStatus("CLICK_SQUAD_CHAP", "Coord fallback for Squadron chapter... (" StateRetries "/" MAX_STATE_RETRIES ")")

        offsets := [0, -(WIN_H * 1 // 100), (WIN_H * 2 // 100)]
        Loop offsets.Length {
            dy := offsets[A_Index]
            ClickMultipleAt(cX, baseCY + dy, 2, 150)
            Sleep(700)

            xT := 0, yT := 0
            if FindNav(SquadChapFile, &xT, &yT, 60) {
                DebugLog("CLICK_SQUAD_CHAP: confirmed via image " SquadChapFile " at (" xT "," yT ") after fallback")
                SetState("CLICK_SQUAD_DIFF")
                return
            }
        }

        DebugLog("CLICK_SQUAD_CHAP: fallback did not confirm " SquadChapFile " — staying in state")
        UpdateStatus("CLICK_SQUAD_CHAP", "Waiting for chapter selection to confirm...")
        return
    }

    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_SQUAD_CHAP: stuck, resetting")
        SetState("DETECT_SCREEN")
        return
    }
    UpdateStatus("CLICK_SQUAD_CHAP", "Looking for chapter button... (" StateRetries ")")
}

HandleClickSquadDiff() {
    global SquadDiffFile, StateRetries, MAX_STATE_RETRIES, WIN_X, WIN_Y, WIN_W, WIN_H
    x := 0, y := 0
    StateRetries++

    ; Normal difficulty is selected by default when a stage is opened, so there is no
    ; button to press — go straight to creating the room. Only Hard needs an explicit click.
    if (SquadDiffFile == "normal_btn.png") {
        DebugLog("CLICK_SQUAD_DIFF: Normal is default — skipping difficulty click, going to Create Room")
        SetState("CLICK_CREATE_ROOM_STAGE")
        return
    }

    ; If Create Room (stage) already visible, difficulty is already selected
    if FindNav("create_room_stage_btn.png", &x, &y) {
        DebugLog("CLICK_SQUAD_DIFF: create_room_stage_btn already visible, skipping diff click")
        SetState("CLICK_CREATE_ROOM_STAGE")
        return
    }

    if ClickMultipleFound(SquadDiffFile, 3, 150) {
        Sleep(800)
        SetState("CLICK_CREATE_ROOM_STAGE")
        return
    }

    ; Coordinate fallback (use raid-style difficulty coordinates; hard vs normal must be distinct)
    if (StateRetries > 2) {
        isHard := (SquadDiffFile == "hard_btn.png")
        coordStr := RaidDiffCoordFallback(isHard)
        parts := StrSplit(coordStr, ",")
        fbX := parts[1]
        fbY := parts[2]

        DebugLog("CLICK_SQUAD_DIFF: image not found — fallback (" fbX "," fbY ") retry=" StateRetries)
        UpdateStatus("CLICK_SQUAD_DIFF", "Coord fallback for Squadron difficulty... (" StateRetries "/" MAX_STATE_RETRIES ")")

        Loop 2 {
            ClickMultipleAt(fbX, fbY, 2, 150)
            Sleep(700)

            xT := 0, yT := 0
            if FindNav(SquadDiffFile, &xT, &yT, 60) {
                DebugLog("CLICK_SQUAD_DIFF: confirmed via image " SquadDiffFile " at (" xT "," yT ") after fallback")
                SetState("CLICK_CREATE_ROOM_STAGE")
                return
            }
            if FindNav("create_room_stage_btn.png", &xT, &yT) {
                DebugLog("CLICK_SQUAD_DIFF: create_room_stage_btn detected after fallback — proceeding")
                SetState("CLICK_CREATE_ROOM_STAGE")
                return
            }
        }

        DebugLog("CLICK_SQUAD_DIFF: fallback did not confirm " SquadDiffFile " — staying in state")
        UpdateStatus("CLICK_SQUAD_DIFF", "Waiting for difficulty selection to confirm...")
        return
    }

    ; After half max retries without finding diff btn, check if Create Room appeared anyway
    ; (handles cases where normal_btn/hard_btn images are not ideal matches)
    if (StateRetries >= MAX_STATE_RETRIES // 2) {
        if FindNav("create_room_stage_btn.png", &x, &y) {
            DebugLog("CLICK_SQUAD_DIFF: create_room_stage_btn appeared after retries, proceeding")
            SetState("CLICK_CREATE_ROOM_STAGE")
            return
        }
    }

    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_SQUAD_DIFF: stuck, resetting")
        SetState("DETECT_SCREEN")
        return
    }
    UpdateStatus("CLICK_SQUAD_DIFF", "Looking for difficulty... (" StateRetries "/" MAX_STATE_RETRIES ")")
}

; ── Create Room (Stage) ──────────────────────────────────────────────────────

HandleClickCreateRoomStage() {
    ; Click the green Create Room button INSIDE the stage panel.
    ; Confirm Start button before transitioning to CLICK_START.
    global StateRetries, MAX_STATE_RETRIES, WIN_X, WIN_Y, WIN_W, WIN_H
    x := 0, y := 0
    StateRetries++

    ; SUCCESS: Start button appeared — room was created, go to start
    if FindNav("start_btn.png", &x, &y) {
        DebugLog("CLICK_CREATE_ROOM_STAGE: start_btn detected, going to CLICK_START")
        SetState("CLICK_START")
        return
    }

    ; Also check if we jumped straight to FARMING state (sometimes Start auto-fires)
    if FindNav("victory_banner.png", &x, &y)
        || FindNav("defeat_banner.png", &x, &y)
        || FindNav("retry_btn.png", &x, &y) {
        SendWebhook("🏁 STAGE END (Direct)")
        SetState("BATTLE_END")
        return
    }

    if FindNav("create_room_stage_btn.png", &x, &y) {
        ClickMultipleAt(x, y, 2, 50)
        DebugLog("CLICK_CREATE_ROOM_STAGE: Clicked at (" x "," y ") — verifying room transition")

        ; Give Roblox time to transition without spamming extra clicks.
        Sleep(700)

        ; Primary: Start button appeared => go to room start.
        if FindNav("start_btn.png", &x, &y) {
            SetState("CLICK_START")
            return
        }

        ; Secondary confirmation (user requested):
        ; If friends_only_btn.png is visible, that confirms the click landed and UI changed.
        ; In that case, don't re-click create_room_stage_btn; just wait for start_btn on next ticks.
        if FindNav("friends_only_btn.png", &x, &y) {
            DebugLog("CLICK_CREATE_ROOM_STAGE: friends_only_btn detected after create_room click — waiting for start_btn (avoid re-click)")
            UpdateStatus("CLICK_CREATE_ROOM_STAGE", "Create clicked (friends_only detected) — waiting for start_btn...")
            return
        }

        DebugLog("CLICK_CREATE_ROOM_STAGE: start_btn not detected yet — waiting for next tick (avoid re-click)")
        UpdateStatus("CLICK_CREATE_ROOM_STAGE", "Waiting for start_btn...")
        return
    }

    ; If we've retried a couple of times and the image still hasn't matched, click by
    ; position. create_room_stage_btn.png is unreliable to detect (its rounded corners
    ; bleed the changing stage art behind them — it image-matched only ~4% of the time in
    ; practice), so we don't depend on it. The Create Room button sits on the same row as
    ; the Friends Only button, which DOES detect reliably, so anchor off that when we can.
    ; Ground truth (window 0,0 / locked 1152x756): Friends Only center = (581,~510),
    ; Create Room center = (747,521) => +166px in X, same row in Y. The old fallback used
    ; Y=72% (~544px) which landed just *below* the button and never registered.
    if (StateRetries > 2) {
        fx := 0, fy := 0
        if FindNav("friends_only_btn.png", &fx, &fy) {
            crsX := fx + 166
            crsY := fy + 20      ; within the ~36px-tall button across the observed Y spread
            DebugLog("CLICK_CREATE_ROOM_STAGE: anchoring Create Room off friends_only at (" crsX "," crsY ")")
        } else {
            crsX := WIN_X + (WIN_W * 648 // 1000)   ; ~747 px (64.8%)
            crsY := WIN_Y + (WIN_H * 705 // 1000)   ; ~533 px (70.5%, midpoint of observed range)
            DebugLog("CLICK_CREATE_ROOM_STAGE: image+friends_only not found, fixed coord fallback (" crsX "," crsY ") retry=" StateRetries)
        }
        UpdateStatus("CLICK_CREATE_ROOM_STAGE", "Coord fallback for Create Room (stage)... (" StateRetries "/" MAX_STATE_RETRIES ")")
        ClickMultipleAt(crsX, crsY, 3, 150)
        Sleep(800)

        if FindNav("start_btn.png", &x, &y) {
            SetState("CLICK_START")
            return
        }
        return
    }

    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_CREATE_ROOM_STAGE: stuck, resetting")
        SetState("DETECT_SCREEN")
        return
    }
    UpdateStatus("CLICK_CREATE_ROOM_STAGE", "Looking for Create Room (stage)... (" StateRetries ")")
}

; ── Start Button (inside room, before battle) ─────────────────────────────────

HandleClickStart() {
    ; Inside the created room. Click Start until the battle begins.
    ; After clicking Start, confirm battle UI (retry/victory/defeat/replay) before FARMING.
    global StateRetries, MAX_STATE_RETRIES, StartButtonSeen, WIN_X, WIN_Y, WIN_W, WIN_H
    x := 0, y := 0
    StateRetries++

    ; Battle has started or ended — leave this state
    if FindNav("victory_banner.png", &x, &y)
        || FindNav("defeat_banner.png", &x, &y)
        || FindNav("retry_btn.png", &x, &y) {
        SendWebhook("🏁 STAGE END (Direct)")
        SetState("BATTLE_END")
        return
    }

    ; Start button visible
    if FindNav("start_btn.png", &x, &y) {
        StartButtonSeen := true
        ClickMultipleAt(x, y, 2, 50)
        DebugLog("CLICK_START: Clicked start_btn at (" x "," y ") retry=" StateRetries)
        Sleep(900)

        ; Confirm we progressed: victory/defeat/retry/replay implies battle is underway/ended
        if FindNav("victory_banner.png", &x, &y)
            || FindNav("defeat_banner.png", &x, &y)
            || FindNav("retry_btn.png", &x, &y)
            || FindNav("replay_btn.png", &x, &y, 130) {
            SetState("FARMING")
            return
        }
        return
    }

    ; Start button not found
    if !StartButtonSeen {
        DebugLog("CLICK_START: start_btn not seen yet, waiting... retry=" StateRetries)
    } else {
        ; Start disappeared; confirm we are in battle, not back at lobby.
        if FindNav("shop_icon.png", &x, &y) {
            SetState("DETECT_SCREEN")
            return
        }

        ; Best-effort battle confirmation: if no battle banners, stay in this state to click again.
        if FindNav("retry_btn.png", &x, &y)
            || FindNav("victory_banner.png", &x, &y)
            || FindNav("defeat_banner.png", &x, &y) {
            SetState("FARMING")
            return
        }

        DebugLog("CLICK_START: start_btn gone but battle UI not confirmed yet — will retry")
    }

    ; Coordinate fallback: start_btn.png is unreliable to detect (same rounded-corner issue
    ; as create_room_stage_btn), but when it IS found it sits consistently at window-rel
    ; (895,535) => 77.7%,70.8% on the locked 1152x756 layout. After a few image misses,
    ; click that position directly so we enter the battle instead of stalling and resetting
    ; all the way back to DETECT_SCREEN.
    if (StateRetries > 3) {
        sbX := WIN_X + (WIN_W * 777 // 1000)
        sbY := WIN_Y + (WIN_H * 708 // 1000)
        DebugLog("CLICK_START: start_btn not detected — coord fallback (" sbX "," sbY ") retry=" StateRetries)
        UpdateStatus("CLICK_START", "Coord fallback for Start... (" StateRetries "/" MAX_STATE_RETRIES ")")
        ClickMultipleAt(sbX, sbY, 2, 80)
        Sleep(900)
        if FindNav("victory_banner.png", &x, &y)
            || FindNav("defeat_banner.png", &x, &y)
            || FindNav("retry_btn.png", &x, &y)
            || FindNav("replay_btn.png", &x, &y, 130) {
            SetState("FARMING")
            return
        }
        ; If the lobby reappeared, we left the room — re-detect rather than spam-clicking.
        if FindNav("shop_icon.png", &x, &y) {
            SetState("DETECT_SCREEN")
            return
        }
    }

    if (StateRetries >= MAX_STATE_RETRIES) {
        DebugLog("CLICK_START: stuck, resetting to DETECT_SCREEN")
        SetState("DETECT_SCREEN")
        return
    }
    UpdateStatus("CLICK_START", "Waiting for or clicking Start... (" StateRetries ")")
}

; ── In-Battle ────────────────────────────────────────────────────────────────

HandleFarming() {
    global VictoryCount, DefeatCount, RunCount, StateRetries, MAX_STATE_RETRIES
    global Cache_Victory, Cache_Defeat, Cache_Retry, Cache_Replay
    global Cache_VictoryX, Cache_VictoryY, Cache_DefeatX, Cache_DefeatY
    global Cache_RetryX, Cache_RetryY, Cache_ReplayX, Cache_ReplayY
    global BattleStartTick
    x := 0, y := 0
    StateRetries++

    ; Safety: Start button reappeared (shouldn't happen mid-battle, but handle it)
    if FindNav("start_btn.png", &x, &y) {
        ClickMultipleAt(x, y, 2, 50)
        return
    }

    ; Check for victory
    if Cache_Victory {
        VictoryCount++
        RunCount++
        SendWebhook("🏆 VICTORY")
        UpdateStatus("FARMING", "Victory detected!")
        SetState("BATTLE_END")
        return
    }

    ; Check for defeat
    if Cache_Defeat {
        DefeatCount++
        RunCount++
        SendWebhook("💀 DEFEAT")
        UpdateStatus("FARMING", "Defeat detected!")
        SetState("BATTLE_END")
        return
    }

    ; Check for retry button (may appear without banners)
    if Cache_Retry {
        RunCount++
        SendWebhook("🏁 STAGE END (Retry)")
        SetState("BATTLE_END")
        return
    }

    ; Check for replay button. Route through BATTLE_END (rather than clicking replay
    ; directly here) so the 30-minute "leave instead of replay" decision is always made
    ; in one place. Otherwise, if the replay button shows without a victory/defeat banner,
    ; we would click Replay and skip the scheduled challenge-reward check. BATTLE_END will
    ; either Leave (at a refresh boundary) or send the REPLAY webhook and click replay.
    if Cache_Replay {
        RunCount++
        UpdateStatus("FARMING", "Replay button detected — post-battle decision")
        SetState("BATTLE_END")
        return
    }

    ; If we see the lobby (shop icon), we got disconnected somehow
    if FindNav("shop_icon.png", &x, &y) {
        DebugLog("FARMING: shop_icon detected — disconnected, returning to DETECT_SCREEN")
        SetState("DETECT_SCREEN")
        return
    }

    ; Failsafe: if stuck in FARMING for too long with no battle events, reset.
    ; Use real elapsed time (4 minutes) instead of a tick count. The old tick-count
    ; check (MAX_STATE_RETRIES * 6 = 120 ticks) fired after only a few seconds at the
    ; 50ms LOOP_INTERVAL, which reset the macro mid-battle and skipped win/loss counting.
    if (BattleStartTick != 0 && (A_TickCount - BattleStartTick) >= 240000) {   ; ~4 minutes
        DebugLog("FARMING: no battle result for " ((A_TickCount - BattleStartTick) // 1000) "s — resetting")
        SetState("DETECT_SCREEN")
        return
    }

    UpdateStatus("FARMING", "Battle in progress... (" StateRetries ")")
    ; Mid-battle there is nothing to do but wait for a result banner. Without a pause
    ; this path would re-run ~8 ImageSearches every 50ms for the whole battle and peg
    ; the CPU; a short throttle keeps end-of-battle detection effectively instant.
    Sleep(100)
}

; ── Post-Battle Decision ─────────────────────────────────────────────────────

HandleBattleEnd() {
    global ActiveFarmMode, OriginalFarmMode, IsCheckingChallenges, RefreshLeaveTries
    global Cache_Retry, Cache_Replay, Cache_RetryX, Cache_RetryY, Cache_ReplayX, Cache_ReplayY
    x := 0, y := 0

    ; === Currently farming Challenge (original or temporary) ===
    if (ActiveFarmMode == "Challenge") {
        if ShouldLeaveChallengeForRefresh() {
            UpdateStatus("BATTLE_END", "Challenge refresh! Leaving to re-check rewards...")
            if LeaveResultsForRefresh() {
                RefreshLeaveTries := 0
                MarkRefreshHandled()
                ; If we were temporarily farming challenge, set up reward re-check
                if (OriginalFarmMode != "Challenge")
                    IsCheckingChallenges := true
                SetState("DETECT_SCREEN")
                return
            }
            ; Leave didn't take yet — keep trying, but don't hang forever.
            RefreshLeaveTries++
            if (RefreshLeaveTries < 30)
                return
            RefreshLeaveTries := 0
            MarkRefreshHandled()   ; give up on this 30-min cycle and keep farming
            DebugLog("BATTLE_END: could not Leave for challenge refresh — skipping cycle, continuing retry/replay")
        }
        ; No refresh — just retry / replay
        if Cache_Retry {
            ClickMultipleAt(Cache_RetryX, Cache_RetryY, 2, 50)
            Sleep(100)
            SetState("WAIT_RETRY")
        } else if Cache_Replay {
            SendWebhook("🔄 REPLAY")
            ClickMultipleAt(Cache_ReplayX, Cache_ReplayY, 2, 50)
            SetState("WAIT_RETRY")
        } else {
            UpdateStatus("BATTLE_END", "Looking for Retry/Replay...")
        }
        return
    }

    ; === Currently farming Raid or Squadron (or Aizen) ===
    if ShouldCheckChallengeNow() {
        UpdateStatus("BATTLE_END", "Refresh! Leaving to check challenges...")
        if LeaveResultsForRefresh() {
            RefreshLeaveTries := 0
            MarkRefreshHandled()
            IsCheckingChallenges := true
            SetState("DETECT_SCREEN")
            return
        }
        ; Leave didn't take yet — keep trying, but don't hang forever.
        RefreshLeaveTries++
        if (RefreshLeaveTries < 30)
            return
        RefreshLeaveTries := 0
        MarkRefreshHandled()   ; give up on this 30-min cycle and keep farming
        DebugLog("BATTLE_END: could not Leave to check challenges — skipping cycle, continuing retry/replay")
    }

    ; Normal retry / replay
    if Cache_Retry {
        ; If webhooks are disabled, we want retries faster (no sleeps / faster spam).
        if (!WebhookEnabled) {
            Loop 3 {
                ClickMultipleAt(Cache_RetryX, Cache_RetryY, 1, 20)
                Sleep(80)
                ; If we navigated away (battle UI changed), stop spamming.
                x := 0, y := 0
                if FindNav("shop_icon.png", &x, &y)
                    || FindNav("retry_btn.png", &x, &y)
                    || FindNav("victory_banner.png", &x, &y)
                    || FindNav("defeat_banner.png", &x, &y) {
                    break
                }
            }
        } else {
            ClickMultipleAt(Cache_RetryX, Cache_RetryY, 2, 50)
            Sleep(100)
        }
        SetState("WAIT_RETRY")
    } else if Cache_Replay {
        if (!WebhookEnabled) {
            SendWebhook("🔄 REPLAY")
            ; Fast spam for replay: repeatedly click replay location until a non-results UI appears.
            Loop 5 {
                ClickMultipleAt(Cache_ReplayX, Cache_ReplayY, 1, 20)
                Sleep(60)
                x := 0, y := 0
                ; Stop spamming once we see the retry screen change triggers.
                if FindNav("retry_btn.png", &x, &y)
                    || FindNav("victory_banner.png", &x, &y)
                    || FindNav("defeat_banner.png", &x, &y)
                    || FindNav("shop_icon.png", &x, &y) {
                    break
                }
            }
        } else {
            SendWebhook("🔄 REPLAY")
            ClickMultipleAt(Cache_ReplayX, Cache_ReplayY, 2, 50)
            Sleep(100)
        }
        SetState("WAIT_RETRY")
    } else {
        UpdateStatus("BATTLE_END", "Looking for Retry/Replay...")
    }
}

; ── Wait for Retry Transition ────────────────────────────────────────────────

HandleWaitRetry() {
    x := 0, y := 0

    ; Still on results screen? Click retry / replay again in case it didn't register
    if FindNav("retry_btn.png", &x, &y) {
        ClickMultipleAt(x, y, 2, 50)
        Sleep(1000)
        return
    }
    if FindNav("replay_btn.png", &x, &y, 130) {
        ClickMultipleAt(x, y, 2, 50)
        return
    }

    ; Banners still visible? Wait for them to clear
    if (FindNav("victory_banner.png", &x, &y)
        || FindNav("defeat_banner.png", &x, &y)) {
        return
    }

    ; Disconnected to lobby?
    if FindNav("shop_icon.png", &x, &y) {
        DebugLog("WAIT_RETRY: shop_icon detected — disconnected, going to DETECT_SCREEN")
        SetState("DETECT_SCREEN")
        return
    }

    ; Start button appeared — we're back in a room
    if FindNav("start_btn.png", &x, &y) {
        SetState("CLICK_START")
        return
    }

    ; Results screen gone — battle has resumed (retry loaded next round)
    SetState("FARMING")
}

; ── Return to Main Mode (after challenge check found nothing) ────────────────

HandleReturnToMainMode() {
    ; We're on the stage selection screen (tabs visible at bottom).
    ; Switch back to the original farming mode by clicking its tab directly.
    global ActiveFarmMode, OriginalFarmMode, IsCheckingChallenges
    IsCheckingChallenges := false
    ActiveFarmMode := OriginalFarmMode

    if (OriginalFarmMode == "Raid")
        SetState("CLICK_RAID_TAB")
    else if (OriginalFarmMode == "Squadron")
        SetState("CLICK_SQUADRON_TAB")
    else if (OriginalFarmMode == "Aizen")
        SetState("CLICK_AIZEN_CHALLENGE")
    else
        SetState("DETECT_SCREEN")   ; safety fallback
}

; ==============================================================================
; UTILITY
; ==============================================================================

SetState(targetState) {
    global State, LeaveAttempts, StateRetries, StartButtonSeen, BattleStartTick
    State := targetState
    LeaveAttempts := 0   ; reset leave-click counter on any state transition
    StateRetries := 0    ; reset generic retry counter on any state transition
    if (targetState == "CLICK_START") {
        StartButtonSeen := false
    }
    if (targetState == "FARMING") {
        ; Record when the battle started so the FARMING failsafe can time out on
        ; real elapsed time rather than tick count (tick count is unreliable here
        ; because FARMING ticks have no sleeps and vary with ImageSearch duration).
        BattleStartTick := A_TickCount
    }
    UpdateStatus(targetState)
    DebugLog("State → " targetState)
}

PositionRobloxWindow() {
    global GAME_TITLE, FIXED_WIN_W, FIXED_WIN_H, SCREEN_W, SCREEN_H, G
    global WIN_X, WIN_Y, WIN_W, WIN_H, RobloxHwnd

    isDocked := false
    if (RobloxHwnd && DllCall("IsWindow", "Ptr", RobloxHwnd)) {
        hwnd := RobloxHwnd
        isDocked := (DllCall("GetParent", "Ptr", hwnd) == G.Hwnd)
    } else {
        hwnd := WinExist(GAME_TITLE)
        if !hwnd {
            RobloxHwnd := 0
            return
        }
        RobloxHwnd := hwnd
    }
    winId := "ahk_id " hwnd

    if !isDocked {
        minMax := WinGetMinMax(winId)
        if (minMax == -1 || minMax == 1)
            WinRestore(winId)
        Sleep(200)

        ; Remove title bar and borders to embed cleanly
        WinSetStyle("-0x00C00000", winId)
        WinSetStyle("-0x00800000", winId)
        WinSetStyle("-0x00040000", winId)
        Sleep(50)

        ; Make Roblox a child of the Macro GUI
        DllCall("SetParent", "Ptr", hwnd, "Ptr", G.Hwnd)
        Sleep(100)
    }

    WinMove(0, 0, FIXED_WIN_W, FIXED_WIN_H, winId)
    Sleep(100)

    WinGetPos(&wx, &wy, &ww, &wh, winId)
    DebugLog("Positioned Roblox at (" wx "," wy ") size " ww "x" wh)

    WIN_X := wx
    WIN_Y := wy
    WIN_W := ww
    WIN_H := wh
}

; ==============================================================================
; DEBUG LOGGING
; ==============================================================================

DebugLog(msg) {
    global DEBUG_LOG, SCRIPT_DIR
    if !DEBUG_LOG
        return
    logFile := SCRIPT_DIR "\debug.log"
    timestamp := FormatTime(, "yyyy-MM-dd HH:mm:ss")
    try FileAppend(timestamp " | " msg "`n", logFile)
}

; ==============================================================================
; SCREENSHOT CAPTURE TOOLS
; ==============================================================================

CaptureDebugScreenshot() {
    ; F3 — Captures the entire Roblox window area and saves to _debug_screenshot.png
    ; This helps verify what ImageSearch actually "sees" at the current window size
    global GAME_TITLE, NAV_DIR, WIN_X, WIN_Y, WIN_W, WIN_H, RobloxHwnd
    
    hwnd := (RobloxHwnd && DllCall("IsWindow", "Ptr", RobloxHwnd)) ? RobloxHwnd : WinExist(GAME_TITLE)
    if !hwnd {
        MsgBox("Roblox window not found!", "Screenshot", "Icon!")
        return
    }
    
    ; Update window bounds
    try WinGetPos(&WIN_X, &WIN_Y, &WIN_W, &WIN_H, "ahk_id " hwnd)
    
    outFile := NAV_DIR "_debug_screenshot.png"
    
    ; Use PowerShell to capture the specific region
    psScript := A_Temp "\capture_debug.ps1"
    ps := ""
    ps .= "Add-Type -AssemblyName System.Windows.Forms`n"
    ps .= "Add-Type -AssemblyName System.Drawing`n"
    ps .= "$bmp = New-Object System.Drawing.Bitmap(" WIN_W ", " WIN_H ")`n"
    ps .= "$g = [System.Drawing.Graphics]::FromImage($bmp)`n"
    ps .= "$g.CopyFromScreen(" WIN_X ", " WIN_Y ", 0, 0, (New-Object System.Drawing.Size(" WIN_W ", " WIN_H ")))`n"
    ps .= "$bmp.Save('" StrReplace(outFile, "'", "''") "', [System.Drawing.Imaging.ImageFormat]::Png)`n"
    ps .= "$g.Dispose()`n"
    ps .= "$bmp.Dispose()`n"
    
    try {
        f := FileOpen(psScript, "w")
        f.Write(ps)
        f.Close()
        RunWait('powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' psScript '"',, "Hide")
        MsgBox("Debug screenshot saved to:`n" outFile "`n`nWindow: " WIN_W "x" WIN_H " at (" WIN_X "," WIN_Y ")`n`nUse this to see exactly what the macro sees. Crop buttons from this image for nav assets!", "Screenshot Captured", "Iconi")
    } catch Error as e {
        MsgBox("Screenshot failed: " e.Message, "Error", "Icon!")
    }
}

CaptureNavAsset() {
    ; F4 — Interactive region capture for creating nav assets
    global GAME_TITLE, NAV_DIR, WIN_X, WIN_Y, WIN_W, WIN_H, RobloxHwnd
    
    hwnd := (RobloxHwnd && DllCall("IsWindow", "Ptr", RobloxHwnd)) ? RobloxHwnd : WinExist(GAME_TITLE)
    if !hwnd {
        MsgBox("Roblox window not found!", "Nav Asset Capture", "Icon!")
        return
    }
    
    ; First position the window properly
    PositionRobloxWindow()
    Sleep(500)
    
    ; Update window bounds
    try WinGetPos(&WIN_X, &WIN_Y, &WIN_W, &WIN_H, "ahk_id " hwnd)
    
    ; Activate Roblox briefly so user sees the game
    try WinActivate("ahk_id " hwnd)
    Sleep(300)
    
    ; Use Snipping Tool instructions
    result := MsgBox(
        "NAV ASSET CAPTURE WORKFLOW`n"
        . "═══════════════════════════`n`n"
        . "1. Press Win+Shift+S to open Snipping Tool`n"
        . "2. Drag to select JUST the button/icon you need`n"
        . "3. Click the notification to open the snip`n"
        . "4. Save it to:`n"
        . "   " NAV_DIR "`n`n"
        . "Use the EXACT filename from the README.`n`n"
        . "Current Roblox window: " WIN_W "x" WIN_H " at (" WIN_X "," WIN_Y ")`n`n"
        . "Alternatively, press F3 first for a full screenshot,`n"
        . "then crop from that image for pixel-perfect accuracy.`n`n"
        . "Click OK when ready to snip, or Cancel.",
        "Nav Asset Capture", "OKCancel Iconi")
    
    if (result == "Cancel")
        return
    
    ; Activate Roblox so user can snip it
    try WinActivate("ahk_id " hwnd)
}




