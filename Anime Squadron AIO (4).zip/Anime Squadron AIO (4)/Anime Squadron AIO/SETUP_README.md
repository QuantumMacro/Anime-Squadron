# Anime Squadron Macro — Setup Guide

> **Send this whole folder to your friends.** Everything they need is inside.

---

## ✅ Requirements

| Requirement | Details |
|---|---|
| **OS** | Windows 10 or Windows 11 |
| **Screen resolution** | **1920 × 1080 or higher** (1080p, 1440p, 4K — all work) |
| **Display scaling** | **Any** (100% / 125% / 150% …) — handled automatically |
| **AutoHotkey** | **v2.x only** — free download below |
| **Roblox** | Must be open before starting the macro |

> 💡 **Works on any monitor.** The macro runs Roblox at a fixed internal size and is fully
> DPI-aware, so it behaves identically whether you're on a 1080p screen at 100% scaling or a
> 1440p/4K screen at 150% scaling. You don't need to change your Windows display settings.

---

## 🚀 First-Time Setup (do this once)

### Step 1 — Install AutoHotkey v2

1. Go to **https://www.autohotkey.com/download/ahk-v2.exe**
2. Run the installer and click through with defaults
3. Done — no configuration needed

> ⚠️ **AHK v1 will NOT work.** Make sure you install v2 specifically.

### Step 2 — Run the Macro

Double-click **`Launch.bat`**

- It automatically checks whether AHK v2 is installed
- If not found, it offers to open the download page for you
- If found, it launches the macro GUI immediately

Alternatively you can right-click **`AnimeSquadronMacro.ahk`** → *Run with AutoHotkey v2*

---

## 🎮 How to Use

1. Open **Roblox** and join Anime Squadron
2. Double-click **`Launch.bat`**
3. The macro GUI will appear — configure your farming settings
4. Press **F1** (or click Start) — the macro will:
   - Automatically resize and position Roblox to the correct size
   - Start detecting screens and farming

> ⚠️ **Important — when you open the macro:**
> - If Roblox was **already open AND already in an Anime Squadron game**, you must **leave and rejoin** Anime Squadron after opening the macro. (The macro needs to embed and resize the Roblox window — rejoining lets it position everything correctly.)
> - If Roblox is sitting on the **homepage / menu** when you open the macro, you **don't need to do anything** — just join Anime Squadron and start.

### Hotkeys

| Key | Action |
|---|---|
| **F1** | Start macro |
| **F2** | Stop and reload (full clean restart) |
| **F3** | Save a debug screenshot (for troubleshooting) |
| **F4** | Nav asset capture helper |
| **F6** | Re-position and re-size the Roblox window |

---

## ⚙️ Farming Modes

### Challenge Farming
Farms the current Regular Challenge in a continuous loop. At every 30-minute refresh (:00 or :30), the macro automatically leaves and re-enters the new challenge.

### Raid Farming
Farms your chosen Raid act and difficulty. Optionally checks for desired Challenge rewards every 30 minutes and temporarily switches to Challenge Farming if found.

### Squadron Farming
Farms your chosen Squadron story, chapter, and difficulty. Same optional 30-minute Challenge check available.

---

## 🖼️ Desired Rewards

Place reward icon screenshots in `assets\rewards\` — they will automatically appear as checkboxes in the GUI.

See `assets\rewards\README.txt` for full instructions.

---

## 🛠 Troubleshooting

### Macro says "Roblox window not found"
Make sure Roblox is fully loaded into the game (past the loading screen) before pressing F1.

### Buttons aren't being detected / macro does nothing
1. Press **F3** to save a debug screenshot to `assets\nav\_debug_screenshot.png`
2. Open that image and compare it to the nav images in `assets\nav\`
3. If Roblox looks different, your images may need to be recaptured at the required resolution

### What resolution does Roblox run at?
The macro forces Roblox to exactly **1152 × 756 pixels** on every PC, positioned at the top-left corner of your screen. This is the resolution all detection images were captured at and cannot be changed without recapturing all nav images.

### I'm on a 1440p / 4K monitor and it wasn't working
This is handled automatically now — the macro is fully DPI-aware and uses real (physical) pixels regardless of your Windows display-scaling setting. If you previously changed your scaling to 100% to make it work, you no longer need to; you can set it back to whatever you like.

### The macro stopped working after an update
If Roblox updates and changes button art, the nav images need to be recaptured. Use **F4** for the asset capture helper.

---

## 📁 Folder Structure

```
Anime Squadron Macro\
├── AnimeSquadronMacro.ahk   ← Main macro script
├── Launch.bat                ← Run this to start
├── SETUP_README.md           ← This file
├── debug.log                 ← Auto-generated debug log
└── assets\
    ├── nav\                  ← Button/icon detection images
    │   └── README.txt        ← Which image is which
    └── rewards\              ← Desired reward icons
        └── README.txt        ← How to add more
```
