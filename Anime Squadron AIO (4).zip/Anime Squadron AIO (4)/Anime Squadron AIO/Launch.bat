@echo off
title Anime Squadron Macro
setlocal

set "SCRIPT=%~dp0AnimeSquadronMacro.ahk"

rem --- Locate AutoHotkey v2 in the usual install locations ---
set "AHK="
for %%P in (
    "%ProgramFiles%\AutoHotkey\v2\AutoHotkey64.exe"
    "%ProgramFiles%\AutoHotkey\v2\AutoHotkey32.exe"
    "%ProgramFiles%\AutoHotkey\v2\AutoHotkey.exe"
    "%ProgramFiles%\AutoHotkey\AutoHotkey.exe"
) do if exist "%%~P" set "AHK=%%~P"

if not defined AHK (
    echo.
    echo   AutoHotkey v2 was not found on this PC.
    echo   The macro needs AutoHotkey v2 to run.
    echo.
    echo   Opening the download page now...
    start "" "https://www.autohotkey.com/download/ahk-v2.exe"
    echo.
    echo   After installing, just double-click Launch.bat again.
    echo.
    pause
    exit /b
)

start "" "%AHK%" "%SCRIPT%"
exit /b
