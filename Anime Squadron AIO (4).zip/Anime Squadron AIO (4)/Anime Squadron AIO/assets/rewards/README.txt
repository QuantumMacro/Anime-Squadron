DESIRED REWARD ASSETS — Place your reward icon PNGs here
==========================================================
Path: Anime Squadron Macro\assets\rewards\

Each .png file you place here automatically becomes a toggleable
checkbox in the macro GUI under "Desired Challenge Rewards".

When the macro checks challenge rewards, it scans the reward icons
visible on the Regular Challenge screen and compares them against
whichever rewards you have ticked ON in the GUI.

────────────────────────────────────────────────
CURRENT DESIRED REWARDS (screenshot and add these)
────────────────────────────────────────────────
  trait_reroll.png          ← Screenshot of the "Trait Reroll" reward icon
  stat_reroll.png           ← Screenshot of the "Stat Reroll" reward icon

════════════════════════════════════════════════
SCREENSHOT TIPS
════════════════════════════════════════════════
  • Open the Regular Challenge screen in-game
  • Zoom in on the reward icons row on the right panel
  • Use Win + Shift + S to crop JUST the icon itself
  • Crop tightly — no background, no border, no text underneath
  • Save as PNG with the EXACT filename listed above
  • Aim for 30-60px wide crops for best detection accuracy

To add MORE desired rewards in future:
  • Take a cropped screenshot of any reward icon
  • Save it here with a descriptive name (e.g. legendary_gem.png)
  • Restart the macro — it will automatically appear as a checkbox
