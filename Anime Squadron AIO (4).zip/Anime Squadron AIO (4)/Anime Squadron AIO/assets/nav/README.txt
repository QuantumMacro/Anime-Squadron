NAVIGATION ASSETS — Place your cropped PNG screenshots here
============================================================
Path: Anime Squadron Macro\assets\nav\

────────────────────────────────────────────────
BATCH 1 — General (used globally across all modes)
────────────────────────────────────────────────
  play_btn.png              ← Red "Play" button in lobby
  shop_icon.png             ← Purple "Shop" button (lobby detection only)
  create_room_btn.png       ← Green "Create Room" button
  start_btn.png             ← "Start" button inside the room
  team_btn.png              ← Yellow "Team" button visible ONLY while inside a stage
                              (battle). Used to confirm the stage actually started and to
                              keep waiting for match-end no matter how long the stage runs.
  retry_btn.png             ← "Retry" button after battle ends
  leave_btn.png             ← Red "Leave" button
  reconnect_btn.png         ← White "Reconnect" button on the "Disconnected"
                              popup (Error Code 277). When detected in ANY state,
                              the macro clicks it and returns to the same farming
                              mode automatically.

────────────────────────────────────────────────
BATCH 2 — Raids
────────────────────────────────────────────────
  raid_tab.png              ← Pink "Raid" bottom tab
  raid_act1.png             ← "Hidden Danger" act button
  raid_act2.png             ← "Saiyan Hunt" act button
  raid_act3.png             ← "Ruler Dragon" act button
  raid_act4.png             ← "The Ultimate Evil" act button
  normal_btn.png            ← Green circle (Normal difficulty)
  hard_btn.png              ← Red skull circle (Hard difficulty)
  create_room_stage_btn.png ← Green "Create Room" button that appears after selecting a stage
  victory_banner.png        ← Victory screen element (for Discord webhook)
  defeat_banner.png         ← Defeat screen element (for Discord webhook)
  replay_btn.png            ← "Replay" button after battle ends

────────────────────────────────────────────────
BATCH 3 — Challenges
────────────────────────────────────────────────
  challenge_tab.png         ← Green "Challenge" bottom tab
  challenge_detection.png   ← Any element only visible AFTER the Challenge tab is
                              opened (e.g. the challenge panel header/title). Used to
                              confirm the Challenge tab was actually clicked. If this
                              file is absent the macro falls back to the challenge images.
  regular_challenge_btn.png ← "Regular Challenge [30m]" entry button

────────────────────────────────────────────────
BATCH 4 — Squadron
────────────────────────────────────────────────
  squadron_tab.png          ← Yellow "Squadron" bottom tab
  squadron_detection.png    ← Any element only visible AFTER the Squadron tab is
                              opened (e.g. the squadron panel header/title). Used to
                              confirm the Squadron tab was actually clicked. If this
                              file is absent the macro falls back to the story images.

  Story buttons (left panel — click to select a story):
  squadron_story1.png       ← "GT City [1]" story entry
  squadron_story2.png       ← "Marine Lobby [2]" story entry
  squadron_story3.png       ← "Ninja Village [3]" story entry

  Chapter buttons (center panel — appear after selecting a story):
  squadron_ch1.png          ← "Chapter 1" button
  squadron_ch2.png          ← "Chapter 2" button
  squadron_ch3.png          ← "Chapter 3" button
  squadron_ch4.png          ← "Chapter 4" button (Ninja Village only)

  NOTE: normal_btn.png, hard_btn.png, create_room_btn.png,
        start_btn.png, retry_btn.png, leave_btn.png from
        Batches 1 & 2 are all reused here — no extra copies needed.

────────────────────────────────────────────────
BATCH 5 — Aizen
────────────────────────────────────────────────
  aizen_btn.png             ← "Katakara Bridge" entry button in the challenge tab

────────────────────────────────────────────────
BATCH 6 — Story
────────────────────────────────────────────────
  Story mode reuses the SAME 3 stories as Squadron (GT City / Marine Lobby /
  Ninja Village) but each has 10 chapters. Story/chapter/difficulty selection is
  fully COORDINATE-based (chapters 8-10 are reached by scrolling the chapter list
  down), so NO per-story or per-chapter images are needed. Only two images are used:

  story_tab.png             ← Blue "Story" bottom tab (leftmost of the 4 tabs).
                              Used to click/confirm the Story tab. If absent, the macro
                              falls back to a coordinate click for the tab.
  story_detection.png       ← Any element only visible AFTER the Story tab is opened
                              (recommended: the big blue "Story" title banner at the top
                              of the panel). Used to confirm the Story tab actually opened
                              before any coordinate clicks. STRONGLY recommended — without
                              it the macro can't verify it reached the Story panel.

  NOTE: normal_btn.png, hard_btn.png, create_room_stage_btn.png, start_btn.png,
        retry_btn.png, leave_btn.png, friends_only_btn.png are all reused here.

════════════════════════════════════════════════
SCREENSHOT TIPS
════════════════════════════════════════════════
  • Use Win + Shift + S (Snipping Tool)
  • Crop as tightly as possible around just the button/icon
  • No background, no surrounding UI chrome
  • Save as PNG with the EXACT filename listed above
  • Aim for 40-120px wide crops for best detection accuracy

TOTAL REQUIRED: 33 nav images (challenge_detection.png, squadron_detection.png and
story_tab.png are optional but recommended; story_detection.png is strongly recommended for Story mode)
